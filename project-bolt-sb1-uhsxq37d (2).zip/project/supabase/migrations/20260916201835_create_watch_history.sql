/*
# Create watch_history table

1. New Tables
   - `watch_history`: Records each time a signed-in user watches a video.
     - `id` (uuid, PK)
     - `user_id` (uuid, not null, default auth.uid(), references profiles ON DELETE CASCADE)
     - `video_id` (uuid, not null, references videos ON DELETE CASCADE)
     - `watched_at` (timestamptz, default now())
     - Unique constraint on (user_id, video_id) — re-watching updates the timestamp instead of creating a duplicate.

2. Indexes
   - `watch_history_user_watched_at` for fetching a user's history sorted by most recent.

3. Security (RLS)
   - History is private: only the owner can read, insert, and delete their own watch history rows.
   - All policies scoped TO authenticated with auth.uid() = user_id.

4. Important Notes
   - The unique (user_id, video_id) constraint means re-watching a video moves it to the top of history
     rather than creating duplicate entries. We use an UPSERT in the app to handle this.
   - Only signed-in users get watch history; anonymous visitors don't generate history rows.
*/

CREATE TABLE IF NOT EXISTS watch_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  watched_at timestamptz DEFAULT now(),
  UNIQUE(user_id, video_id)
);

ALTER TABLE watch_history ENABLE ROW LEVEL SECURITY;

-- Only owner can read their history
DROP POLICY IF EXISTS "history_read_own" ON watch_history;
CREATE POLICY "history_read_own"
ON watch_history FOR SELECT
TO authenticated USING (auth.uid() = user_id);

-- Only owner can insert (upsert) their history
DROP POLICY IF EXISTS "history_insert_own" ON watch_history;
CREATE POLICY "history_insert_own"
ON watch_history FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

-- Only owner can update (for upsert timestamp refresh)
DROP POLICY IF EXISTS "history_update_own" ON watch_history;
CREATE POLICY "history_update_own"
ON watch_history FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Only owner can delete their history
DROP POLICY IF EXISTS "history_delete_own" ON watch_history;
CREATE POLICY "history_delete_own"
ON watch_history FOR DELETE
TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS watch_history_user_watched_at ON watch_history (user_id, watched_at DESC);