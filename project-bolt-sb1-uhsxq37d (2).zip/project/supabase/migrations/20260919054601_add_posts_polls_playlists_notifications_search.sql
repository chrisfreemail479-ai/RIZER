/*
# Add posts, polls, playlists, notifications, search history, subscription preferences, and Rezzer music metadata

1. New Tables
   - `posts`: Text, image, and poll posts (like a social feed on channels).
     - `id` (uuid, PK)
     - `user_id` (uuid, not null, default auth.uid(), references profiles)
     - `content_type` (text: 'text' | 'image' | 'poll')
     - `body` (text, nullable — the text content)
     - `image_url` (text, nullable — image for image posts)
     - `created_at` (timestamptz, default now())
   - `poll_options`: Options for poll posts.
     - `id` (uuid, PK)
     - `post_id` (uuid, not null, references posts ON DELETE CASCADE)
     - `label` (text, not null)
     - `position` (int, not null default 0)
   - `poll_votes`: Votes on poll options.
     - `id` (uuid, PK)
     - `option_id` (uuid, not null, references poll_options ON DELETE CASCADE)
     - `user_id` (uuid, not null, default auth.uid(), references profiles)
     - `created_at` (timestamptz, default now())
     - Unique on (option_id, user_id)
   - `playlists`: User-created playlists (public or private).
     - `id` (uuid, PK)
     - `user_id` (uuid, not null, default auth.uid(), references profiles)
     - `name` (text, not null)
     - `description` (text, nullable)
     - `is_public` (boolean, default false)
     - `created_at` (timestamptz, default now())
   - `playlist_items`: Videos in a playlist.
     - `id` (uuid, PK)
     - `playlist_id` (uuid, not null, references playlists ON DELETE CASCADE)
     - `video_id` (uuid, not null, references videos ON DELETE CASCADE)
     - `position` (int, not null default 0)
     - `added_at` (timestamptz, default now())
     - Unique on (playlist_id, video_id)
   - `notifications`: Notifications for users (new subscriber, comment, like, etc).
     - `id` (uuid, PK)
     - `user_id` (uuid, not null, references profiles — the recipient)
     - `actor_id` (uuid, nullable, references profiles — who triggered it)
     - `type` (text: 'subscribe' | 'comment' | 'like' | 'reply' | 'video')
     - `entity_id` (uuid, nullable — video id or post id depending on type)
     - `message` (text, nullable)
     - `is_read` (boolean, default false)
     - `created_at` (timestamptz, default now())
   - `search_history`: Recent search queries per user.
     - `id` (uuid, PK)
     - `user_id` (uuid, not null, default auth.uid(), references profiles)
     - `query` (text, not null)
     - `created_at` (timestamptz, default now())
     - Unique on (user_id, query)

2. Modified Tables
   - `subscriptions`: Added `personalize` (boolean, default false) — whether the subscriber wants personalized notifications from this channel.
   - `videos`: Added `music_title` (text, nullable) and `clip_duration` (int, nullable) — for Rezzer music and duration metadata.

3. Indexes
   - `posts_user_id` for listing posts per channel
   - `poll_votes_option_id` for counting votes
   - `playlists_user_id` for listing user's playlists
   - `playlist_items_playlist_id` for listing items
   - `notifications_user_id` for listing notifications
   - `search_history_user_id` for listing search history

4. Security (RLS)
   - `posts`: Public read. Only authenticated users can create/update/delete their own.
   - `poll_options`: Public read. Only the post owner can create options (checked via post ownership).
   - `poll_votes`: Public read. Only authenticated users can vote and delete their own votes.
   - `playlists`: Public read for public playlists; owner can read all their own. Only authenticated users can create/update/delete their own.
   - `playlist_items`: Read follows playlist visibility. Only playlist owner can add/remove items.
   - `notifications`: Only the recipient can read and mark their own as read. Only authenticated users can create (system-generated).
   - `search_history`: Only the owner can read and delete their own.

5. Important Notes
   - Posts are public like channel content.
   - Poll votes are one per user per option.
   - Playlists can be private (only owner sees) or public (everyone sees).
   - Notifications are only visible to the recipient.
   - Search history is private to each user.
   - Subscription `personalize` flag lets users opt into personalized content from a channel.
*/

-- ============================================================
-- POSTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  content_type text NOT NULL DEFAULT 'text' CHECK (content_type IN ('text', 'image', 'poll')),
  body text,
  image_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE posts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "posts_public_read" ON posts;
CREATE POLICY "posts_public_read" ON posts FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "posts_insert_own" ON posts;
CREATE POLICY "posts_insert_own" ON posts FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "posts_update_own" ON posts;
CREATE POLICY "posts_update_own" ON posts FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "posts_delete_own" ON posts;
CREATE POLICY "posts_delete_own" ON posts FOR DELETE
TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS posts_user_id ON posts (user_id, created_at DESC);

-- ============================================================
-- POLL_OPTIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS poll_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  label text NOT NULL,
  position int NOT NULL DEFAULT 0
);

ALTER TABLE poll_options ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "poll_options_public_read" ON poll_options;
CREATE POLICY "poll_options_public_read" ON poll_options FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "poll_options_insert_own" ON poll_options;
CREATE POLICY "poll_options_insert_own" ON poll_options FOR INSERT
TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM posts WHERE posts.id = poll_options.post_id AND posts.user_id = auth.uid())
);

DROP POLICY IF EXISTS "poll_options_delete_own" ON poll_options;
CREATE POLICY "poll_options_delete_own" ON poll_options FOR DELETE
TO authenticated USING (
  EXISTS (SELECT 1 FROM posts WHERE posts.id = poll_options.post_id AND posts.user_id = auth.uid())
);

CREATE INDEX IF NOT EXISTS poll_options_post_id ON poll_options (post_id);

-- ============================================================
-- POLL_VOTES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS poll_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  option_id uuid NOT NULL REFERENCES poll_options(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(option_id, user_id)
);

ALTER TABLE poll_votes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "poll_votes_public_read" ON poll_votes;
CREATE POLICY "poll_votes_public_read" ON poll_votes FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "poll_votes_insert_own" ON poll_votes;
CREATE POLICY "poll_votes_insert_own" ON poll_votes FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "poll_votes_delete_own" ON poll_votes;
CREATE POLICY "poll_votes_delete_own" ON poll_votes FOR DELETE
TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS poll_votes_option_id ON poll_votes (option_id);

-- ============================================================
-- PLAYLISTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS playlists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  is_public boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE playlists ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "playlists_select" ON playlists;
CREATE POLICY "playlists_select" ON playlists FOR SELECT
TO anon, authenticated USING (is_public = true OR user_id = auth.uid());

DROP POLICY IF EXISTS "playlists_insert_own" ON playlists;
CREATE POLICY "playlists_insert_own" ON playlists FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "playlists_update_own" ON playlists;
CREATE POLICY "playlists_update_own" ON playlists FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "playlists_delete_own" ON playlists;
CREATE POLICY "playlists_delete_own" ON playlists FOR DELETE
TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS playlists_user_id ON playlists (user_id);

-- ============================================================
-- PLAYLIST_ITEMS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS playlist_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  playlist_id uuid NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
  video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  position int NOT NULL DEFAULT 0,
  added_at timestamptz DEFAULT now(),
  UNIQUE(playlist_id, video_id)
);

ALTER TABLE playlist_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "playlist_items_select" ON playlist_items;
CREATE POLICY "playlist_items_select" ON playlist_items FOR SELECT
TO anon, authenticated USING (
  EXISTS (SELECT 1 FROM playlists WHERE playlists.id = playlist_items.playlist_id AND (playlists.is_public = true OR playlists.user_id = auth.uid()))
);

DROP POLICY IF EXISTS "playlist_items_insert_own" ON playlist_items;
CREATE POLICY "playlist_items_insert_own" ON playlist_items FOR INSERT
TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM playlists WHERE playlists.id = playlist_items.playlist_id AND playlists.user_id = auth.uid())
);

DROP POLICY IF EXISTS "playlist_items_delete_own" ON playlist_items;
CREATE POLICY "playlist_items_delete_own" ON playlist_items FOR DELETE
TO authenticated USING (
  EXISTS (SELECT 1 FROM playlists WHERE playlists.id = playlist_items.playlist_id AND playlists.user_id = auth.uid())
);

CREATE INDEX IF NOT EXISTS playlist_items_playlist_id ON playlist_items (playlist_id, position);

-- ============================================================
-- NOTIFICATIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  actor_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  type text NOT NULL CHECK (type IN ('subscribe', 'comment', 'like', 'reply', 'video')),
  entity_id uuid,
  message text,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "notifications_select_own" ON notifications;
CREATE POLICY "notifications_select_own" ON notifications FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "notifications_insert_own" ON notifications;
CREATE POLICY "notifications_insert_own" ON notifications FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id OR auth.uid() = actor_id);

DROP POLICY IF EXISTS "notifications_update_own" ON notifications;
CREATE POLICY "notifications_update_own" ON notifications FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "notifications_delete_own" ON notifications;
CREATE POLICY "notifications_delete_own" ON notifications FOR DELETE
TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS notifications_user_id ON notifications (user_id, created_at DESC);

-- ============================================================
-- SEARCH_HISTORY TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS search_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  query text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, query)
);

ALTER TABLE search_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "search_history_select_own" ON search_history;
CREATE POLICY "search_history_select_own" ON search_history FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "search_history_insert_own" ON search_history;
CREATE POLICY "search_history_insert_own" ON search_history FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "search_history_delete_own" ON search_history;
CREATE POLICY "search_history_delete_own" ON search_history FOR DELETE
TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS search_history_user_id ON search_history (user_id, created_at DESC);

-- ============================================================
-- ADD personalize TO subscriptions
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'subscriptions' AND column_name = 'personalize') THEN
    ALTER TABLE subscriptions ADD COLUMN personalize boolean NOT NULL DEFAULT false;
  END IF;
END $$;

-- ============================================================
-- ADD music_title and clip_duration TO videos
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'videos' AND column_name = 'music_title') THEN
    ALTER TABLE videos ADD COLUMN music_title text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'videos' AND column_name = 'clip_duration') THEN
    ALTER TABLE videos ADD COLUMN clip_duration int;
  END IF;
END $$;