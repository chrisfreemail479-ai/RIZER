/*
# RIZER - Core Schema

1. Purpose
   RIZER is a YouTube-like video sharing platform. Users create accounts to post videos
   (either by uploading a file or providing a YouTube link), comment on videos, and like videos.

2. New Tables
   - `profiles`: Public user profile data (display name, avatar URL) linked to auth.users.
     - `id` (uuid, PK, references auth.users)
     - `username` (text, unique, not null)
     - `display_name` (text, not null)
     - `avatar_url` (text, nullable)
     - `created_at` (timestamptz, default now())
   - `videos`: Videos posted by users. Can be a file upload (stored in Supabase Storage) or a YouTube link.
     - `id` (uuid, PK)
     - `user_id` (uuid, not null, default auth.uid(), references profiles)
     - `title` (text, not null)
     - `description` (text, nullable)
     - `video_type` (text, not null) — 'file' or 'youtube'
     - `video_url` (text, nullable) — storage path for file uploads
     - `youtube_id` (text, nullable) — YouTube video ID for YouTube links
     - `thumbnail_url` (text, nullable) — storage path or YouTube thumbnail
     - `views` (integer, default 0)
     - `created_at` (timestamptz, default now())
   - `comments`: Comments on videos.
     - `id` (uuid, PK)
     - `video_id` (uuid, not null, references videos ON DELETE CASCADE)
     - `user_id` (uuid, not null, default auth.uid(), references profiles)
     - `content` (text, not null)
     - `created_at` (timestamptz, default now())
   - `likes`: Like relationships between users and videos.
     - `id` (uuid, PK)
     - `video_id` (uuid, not null, references videos ON DELETE CASCADE)
     - `user_id` (uuid, not null, default auth.uid(), references profiles)
     - `created_at` (timestamptz, default now())
     - Unique constraint on (video_id, user_id) to prevent duplicate likes.

3. Indexes
   - `videos_created_at_desc` for home feed ordering
   - `comments_video_id_created_at` for fetching comments by video
   - `likes_video_id` for counting likes per video
   - `videos_user_id` for channel page

4. Security (RLS)
   - `profiles`: Users can read all profiles (public). Users can update/insert only their own profile.
   - `videos`: Anyone (including anon) can read all videos. Only authenticated owners can insert/update/delete their own videos.
   - `comments`: Anyone can read comments. Only authenticated users can comment. Owners can delete their own comments.
   - `likes`: Anyone can read likes. Only authenticated users can like/unlike. Owners can remove their own likes.
   Since videos, comments, and likes are publicly viewable (like YouTube), SELECT policies use `TO anon, authenticated` with `USING (true)`.
   Write operations are restricted to authenticated owners.

5. Storage
   - `videos` bucket: for uploaded video files. Public read, authenticated write to user's own folder.
   - `thumbnails` bucket: for uploaded thumbnail images. Public read, authenticated write to user's own folder.
   - `avatars` bucket: for user avatar images. Public read, authenticated write to user's own folder.

6. Important Notes
   - All owner columns default to `auth.uid()` so frontend inserts omitting `user_id` succeed.
   - Videos are publicly readable so unauthenticated visitors can browse.
   - Comments and likes require authentication to create (sign-in required to interact).
   - Storage policies use `auth.uid()` to scope uploads to user-specific folders.
*/

-- ============================================================
-- PROFILES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  display_name text NOT NULL,
  avatar_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Profiles: public read
DROP POLICY IF EXISTS "profiles_public_read" ON profiles;
CREATE POLICY "profiles_public_read"
ON profiles FOR SELECT
TO anon, authenticated USING (true);

-- Profiles: insert own (on signup)
DROP POLICY IF EXISTS "profiles_insert_own" ON profiles;
CREATE POLICY "profiles_insert_own"
ON profiles FOR INSERT
TO authenticated WITH CHECK (auth.uid() = id);

-- Profiles: update own
DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own"
ON profiles FOR UPDATE
TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ============================================================
-- VIDEOS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  video_type text NOT NULL CHECK (video_type IN ('file', 'youtube')),
  video_url text,
  youtube_id text,
  thumbnail_url text,
  views integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE videos ENABLE ROW LEVEL SECURITY;

-- Videos: public read
DROP POLICY IF EXISTS "videos_public_read" ON videos;
CREATE POLICY "videos_public_read"
ON videos FOR SELECT
TO anon, authenticated USING (true);

-- Videos: insert own
DROP POLICY IF EXISTS "videos_insert_own" ON videos;
CREATE POLICY "videos_insert_own"
ON videos FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

-- Videos: update own
DROP POLICY IF EXISTS "videos_update_own" ON videos;
CREATE POLICY "videos_update_own"
ON videos FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Videos: delete own
DROP POLICY IF EXISTS "videos_delete_own" ON videos;
CREATE POLICY "videos_delete_own"
ON videos FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- COMMENTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE comments ENABLE ROW LEVEL SECURITY;

-- Comments: public read
DROP POLICY IF EXISTS "comments_public_read" ON comments;
CREATE POLICY "comments_public_read"
ON comments FOR SELECT
TO anon, authenticated USING (true);

-- Comments: insert own
DROP POLICY IF EXISTS "comments_insert_own" ON comments;
CREATE POLICY "comments_insert_own"
ON comments FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

-- Comments: delete own
DROP POLICY IF EXISTS "comments_delete_own" ON comments;
CREATE POLICY "comments_delete_own"
ON comments FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- LIKES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(video_id, user_id)
);

ALTER TABLE likes ENABLE ROW LEVEL SECURITY;

-- Likes: public read
DROP POLICY IF EXISTS "likes_public_read" ON likes;
CREATE POLICY "likes_public_read"
ON likes FOR SELECT
TO anon, authenticated USING (true);

-- Likes: insert own
DROP POLICY IF EXISTS "likes_insert_own" ON likes;
CREATE POLICY "likes_insert_own"
ON likes FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

-- Likes: delete own
DROP POLICY IF EXISTS "likes_delete_own" ON likes;
CREATE POLICY "likes_delete_own"
ON likes FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS videos_created_at_desc ON videos (created_at DESC);
CREATE INDEX IF NOT EXISTS videos_user_id ON videos (user_id);
CREATE INDEX IF NOT EXISTS comments_video_id_created_at ON comments (video_id, created_at DESC);
CREATE INDEX IF NOT EXISTS likes_video_id ON likes (video_id);
CREATE INDEX IF NOT EXISTS likes_user_id ON likes (user_id);

-- ============================================================
-- STORAGE BUCKETS
-- ============================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('videos', 'videos', true)
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public)
VALUES ('thumbnails', 'thumbnails', true)
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public)
VALUES ('avatars', 'avatars', true)
ON CONFLICT (id) DO NOTHING;

-- Storage: videos bucket — public read, authenticated write to own folder
DROP POLICY IF EXISTS "videos_bucket_public_read" ON storage.objects;
CREATE POLICY "videos_bucket_public_read"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'videos');

DROP POLICY IF EXISTS "videos_bucket_auth_insert" ON storage.objects;
CREATE POLICY "videos_bucket_auth_insert"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'videos' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "videos_bucket_auth_update" ON storage.objects;
CREATE POLICY "videos_bucket_auth_update"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'videos' AND (storage.foldername(name))[1] = auth.uid()::text)
WITH CHECK (bucket_id = 'videos' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "videos_bucket_auth_delete" ON storage.objects;
CREATE POLICY "videos_bucket_auth_delete"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'videos' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Storage: thumbnails bucket
DROP POLICY IF EXISTS "thumbnails_bucket_public_read" ON storage.objects;
CREATE POLICY "thumbnails_bucket_public_read"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'thumbnails');

DROP POLICY IF EXISTS "thumbnails_bucket_auth_insert" ON storage.objects;
CREATE POLICY "thumbnails_bucket_auth_insert"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'thumbnails' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "thumbnails_bucket_auth_update" ON storage.objects;
CREATE POLICY "thumbnails_bucket_auth_update"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'thumbnails' AND (storage.foldername(name))[1] = auth.uid()::text)
WITH CHECK (bucket_id = 'thumbnails' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "thumbnails_bucket_auth_delete" ON storage.objects;
CREATE POLICY "thumbnails_bucket_auth_delete"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'thumbnails' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Storage: avatars bucket
DROP POLICY IF EXISTS "avatars_bucket_public_read" ON storage.objects;
CREATE POLICY "avatars_bucket_public_read"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'avatars');

DROP POLICY IF EXISTS "avatars_bucket_auth_insert" ON storage.objects;
CREATE POLICY "avatars_bucket_auth_insert"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "avatars_bucket_auth_update" ON storage.objects;
CREATE POLICY "avatars_bucket_auth_update"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text)
WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "avatars_bucket_auth_delete" ON storage.objects;
CREATE POLICY "avatars_bucket_auth_delete"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

-- ============================================================
-- INCREMENT VIEWS FUNCTION (SECURITY DEFINER, safe)
-- ============================================================
CREATE OR REPLACE FUNCTION increment_views(video_uuid uuid)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
AS $$
  UPDATE videos SET views = views + 1 WHERE id = video_uuid;
$$;

GRANT EXECUTE ON FUNCTION increment_views TO anon, authenticated;