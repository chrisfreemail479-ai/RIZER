/*
# Add bio and banner_url to profiles

1. Modified Tables
   - `profiles`: added two new nullable columns.
     - `bio` (text, nullable) — a short channel description shown on the channel page.
     - `banner_url` (text, nullable) — URL to a custom banner image stored in the avatars storage bucket.

2. Security
   - No new policies needed — the existing `profiles_update_own` policy already allows
     authenticated users to update their own row, which now includes these new columns.
   - The `profiles_public_read` SELECT policy already covers the new columns (it uses USING true).

3. Important Notes
   - Both columns are nullable so existing profiles are unaffected.
   - Banner images are stored in the existing `avatars` bucket under the user's folder,
     so no new storage bucket or storage policies are needed.
*/

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS bio text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS banner_url text;