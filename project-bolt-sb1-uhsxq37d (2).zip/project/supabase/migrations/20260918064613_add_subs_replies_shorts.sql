/*
# Add subscriptions, comment replies, comment likes, and shorts

1. New Tables
   - `subscriptions`: Follow/subscribe relationship between users.
     - `id` (uuid, PK)
     - `subscriber_id` (uuid, not null, default auth.uid(), references profiles)
     - `channel_id` (uuid, not null, references profiles)
     - `created_at` (timestamptz, default now())
     - Unique constraint on (subscriber_id, channel_id)
   - `comment_likes`: Likes on individual comments.
     - `id` (uuid, PK)
     - `comment_id` (uuid, not null, references comments ON DELETE CASCADE)
     - `user_id` (uuid, not null, default auth.uid(), references profiles)
     - `created_at` (timestamptz, default now())
     - Unique constraint on (comment_id, user_id)

2. Modified Tables
   - `comments`: Added `parent_id` (uuid, nullable, self-referencing FK) for threaded replies.
   - `videos`: Added `is_short` (boolean, default false) to mark Rezzer/shorts.

3. Indexes
   - `subscriptions_subscriber` for listing who a user follows
   - `subscriptions_channel` for counting subscribers per channel
   - `comment_likes_comment_id` for counting likes per comment

4. Security (RLS)
   - `subscriptions`: Public read. Only authenticated users can subscribe/unsubscribe their own.
   - `comment_likes`: Public read. Only authenticated users can like/unlike their own.

5. Important Notes
   - Subscriptions are public (like YouTube subscribe).
   - Comment replies use a self-referencing parent_id on the comments table.
   - is_short defaults to false so existing videos are unaffected.
*/

-- ============================================================
-- SUBSCRIPTIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscriber_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  channel_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(subscriber_id, channel_id)
);

ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "subscriptions_public_read" ON subscriptions;
CREATE POLICY "subscriptions_public_read"
ON subscriptions FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "subscriptions_insert_own" ON subscriptions;
CREATE POLICY "subscriptions_insert_own"
ON subscriptions FOR INSERT
TO authenticated WITH CHECK (auth.uid() = subscriber_id);

DROP POLICY IF EXISTS "subscriptions_delete_own" ON subscriptions;
CREATE POLICY "subscriptions_delete_own"
ON subscriptions FOR DELETE
TO authenticated USING (auth.uid() = subscriber_id);

CREATE INDEX IF NOT EXISTS subscriptions_subscriber ON subscriptions (subscriber_id);
CREATE INDEX IF NOT EXISTS subscriptions_channel ON subscriptions (channel_id);

-- ============================================================
-- COMMENT_LIKES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS comment_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  comment_id uuid NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(comment_id, user_id)
);

ALTER TABLE comment_likes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "comment_likes_public_read" ON comment_likes;
CREATE POLICY "comment_likes_public_read"
ON comment_likes FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "comment_likes_insert_own" ON comment_likes;
CREATE POLICY "comment_likes_insert_own"
ON comment_likes FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "comment_likes_delete_own" ON comment_likes;
CREATE POLICY "comment_likes_delete_own"
ON comment_likes FOR DELETE
TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS comment_likes_comment_id ON comment_likes (comment_id);

-- ============================================================
-- ADD parent_id TO comments (for replies)
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'comments' AND column_name = 'parent_id') THEN
    ALTER TABLE comments ADD COLUMN parent_id uuid REFERENCES comments(id) ON DELETE CASCADE;
    CREATE INDEX comments_parent_id ON comments (parent_id);
  END IF;
END $$;

-- ============================================================
-- ADD is_short TO videos (for Rezzer/shorts)
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'videos' AND column_name = 'is_short') THEN
    ALTER TABLE videos ADD COLUMN is_short boolean NOT NULL DEFAULT false;
  END IF;
END $$;