import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { formatCount } from '@/lib/utils';

interface SubscribeButtonProps {
  channelId: string;
  onOpenAuth: () => void;
}

export function SubscribeButton({ channelId, onOpenAuth }: SubscribeButtonProps) {
  const { user } = useAuth();
  const [subscribed, setSubscribed] = useState(false);
  const [subCount, setSubCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSubState = async () => {
      const { count } = await supabase
        .from('subscriptions')
        .select('*', { count: 'exact', head: true })
        .eq('channel_id', channelId);
      setSubCount(count ?? 0);

      if (user) {
        const { data } = await supabase
          .from('subscriptions')
          .select('id')
          .eq('subscriber_id', user.id)
          .eq('channel_id', channelId)
          .maybeSingle();
        setSubscribed(!!data);
      }
      setLoading(false);
    };
    fetchSubState();
  }, [channelId, user]);

  const handleToggle = async () => {
    if (!user) {
      onOpenAuth();
      return;
    }
    if (subscribed) {
      await supabase.from('subscriptions').delete().eq('subscriber_id', user.id).eq('channel_id', channelId);
      setSubscribed(false);
      setSubCount((c) => c - 1);
    } else {
      await supabase.from('subscriptions').insert({ subscriber_id: user.id, channel_id: channelId });
      setSubscribed(true);
      setSubCount((c) => c + 1);
    }
  };

  if (loading) return null;

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={handleToggle}
        className={`rounded-full px-5 py-2 text-sm font-semibold transition ${
          subscribed
            ? 'bg-neutral-800 text-neutral-200 hover:bg-neutral-700'
            : 'bg-white text-black hover:bg-neutral-200'
        }`}
      >
        {subscribed ? 'Subscribed' : 'Subscribe'}
      </button>
      {subCount > 0 && (
        <span className="text-xs text-neutral-500">{formatCount(subCount)} {subCount === 1 ? 'subscriber' : 'subscribers'}</span>
      )}
    </div>
  );
}
