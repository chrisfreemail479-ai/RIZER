import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Type, ImagePlus, BarChart3, X, Send, Loader2 } from 'lucide-react';

interface PostComposerProps {
  userId: string;
  onPosted: () => void;
}

export function PostComposer({ userId, onPosted }: PostComposerProps) {
  const { user, profile } = useAuth();
  const [mode, setMode] = useState<'text' | 'image' | 'poll' | null>(null);
  const [body, setBody] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!user || user.id !== userId) return null;

  const reset = () => {
    setMode(null); setBody(''); setImageFile(null); setImagePreview(null);
    setPollOptions(['', '']); setError(null);
  };

  const handlePost = async () => {
    if (!user) return;
    setPosting(true);
    setError(null);

    try {
      let imageUrl: string | null = null;

      if (mode === 'image') {
        if (!imageFile) { setError('Please select an image'); setPosting(false); return; }
        if (!body.trim()) { setError('Please add a caption'); setPosting(false); return; }
        const ext = imageFile.name.split('.').pop();
        const path = `${user.id}/${Date.now()}.${ext}`;
        const { error: upErr } = await supabase.storage.from('thumbnails').upload(path, imageFile);
        if (upErr) throw new Error('Image upload failed');
        imageUrl = supabase.storage.from('thumbnails').getPublicUrl(path).data.publicUrl;
      } else if (mode === 'poll') {
        const valid = pollOptions.filter((o) => o.trim());
        if (valid.length < 2) { setError('Add at least 2 poll options'); setPosting(false); return; }
        if (!body.trim()) { setError('Add a poll question'); setPosting(false); return; }
      } else if (mode === 'text') {
        if (!body.trim()) { setError('Write something'); setPosting(false); return; }
      }

      const contentType = mode === 'image' ? 'image' : mode === 'poll' ? 'poll' : 'text';
      const { data: post, error: pErr } = await supabase
        .from('posts')
        .insert({ user_id: user.id, content_type: contentType, body: body.trim(), image_url: imageUrl })
        .select('id')
        .single();
      if (pErr) throw new Error('Failed to create post');

      if (mode === 'poll') {
        const valid = pollOptions.filter((o) => o.trim());
        const inserts = valid.map((label, i) => ({ post_id: post.id, label: label.trim(), position: i }));
        await supabase.from('poll_options').insert(inserts);
      }

      reset();
      onPosted();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to post');
    } finally {
      setPosting(false);
    }
  };

  return (
    <div className="rounded-xl border border-neutral-800 bg-neutral-900 p-4">
      <div className="mb-3 flex items-center gap-2">
        <div className="h-9 w-9 overflow-hidden rounded-full bg-gradient-to-br from-red-500 to-orange-500">
          {profile?.avatar_url ? (
            <img src={profile.avatar_url} alt="avatar" className="h-full w-full object-cover" />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-sm font-bold text-white">{(profile?.display_name?.[0] ?? 'U').toUpperCase()}</div>
          )}
        </div>
        <button
          onClick={() => setMode(mode === 'text' ? null : 'text')}
          className="flex-1 rounded-full bg-neutral-800 px-4 py-2 text-left text-sm text-neutral-400 transition hover:bg-neutral-700"
        >
          Share an update...
        </button>
      </div>

      {!mode && (
        <div className="flex gap-2">
          <button onClick={() => setMode('text')} className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs text-neutral-400 transition hover:bg-neutral-800 hover:text-white"><Type size={14} /> Text</button>
          <button onClick={() => setMode('image')} className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs text-neutral-400 transition hover:bg-neutral-800 hover:text-white"><ImagePlus size={14} /> Image</button>
          <button onClick={() => setMode('poll')} className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs text-neutral-400 transition hover:bg-neutral-800 hover:text-white"><BarChart3 size={14} /> Poll</button>
        </div>
      )}

      {mode && (
        <div className="space-y-3">
          {mode === 'image' && (
            <div>
              {imagePreview ? (
                <div className="relative">
                  <img src={imagePreview} alt="preview" className="max-h-64 w-full rounded-lg object-cover" />
                  <button onClick={() => { setImageFile(null); setImagePreview(null); }} className="absolute right-2 top-2 rounded-full bg-black/70 p-1.5 text-white"><X size={14} /></button>
                </div>
              ) : (
                <label className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-neutral-700 py-8 transition hover:border-neutral-500">
                  <ImagePlus size={24} className="text-neutral-500" />
                  <span className="mt-2 text-xs text-neutral-400">Upload an image</span>
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) { setImageFile(f); setImagePreview(URL.createObjectURL(f)); } }} />
                </label>
              )}
            </div>
          )}

          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder={mode === 'poll' ? 'Ask a question...' : 'Write something...'}
            rows={mode === 'poll' ? 1 : 3}
            maxLength={500}
            className="w-full resize-none rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-2 text-sm text-white outline-none focus:border-neutral-500"
          />

          {mode === 'poll' && (
            <div className="space-y-2">
              {pollOptions.map((opt, i) => (
                <div key={i} className="flex gap-2">
                  <input
                    type="text"
                    value={opt}
                    onChange={(e) => setPollOptions((prev) => prev.map((o, idx) => idx === i ? e.target.value : o))}
                    placeholder={`Option ${i + 1}`}
                    maxLength={100}
                    className="flex-1 rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-2 text-sm text-white outline-none focus:border-neutral-500"
                  />
                  {pollOptions.length > 2 && (
                    <button onClick={() => setPollOptions((prev) => prev.filter((_, idx) => idx !== i))} className="text-neutral-500 hover:text-red-400"><X size={16} /></button>
                  )}
                </div>
              ))}
              {pollOptions.length < 6 && (
                <button onClick={() => setPollOptions((prev) => [...prev, ''])} className="text-xs text-neutral-400 hover:text-white">+ Add option</button>
              )}
            </div>
          )}

          {error && <p className="text-xs text-red-400">{error}</p>}

          <div className="flex items-center justify-between">
            <div className="flex gap-1">
              <button onClick={() => setMode('text')} className={`rounded p-1.5 transition ${mode === 'text' ? 'text-red-400' : 'text-neutral-500 hover:text-white'}`}><Type size={16} /></button>
              <button onClick={() => setMode('image')} className={`rounded p-1.5 transition ${mode === 'image' ? 'text-red-400' : 'text-neutral-500 hover:text-white'}`}><ImagePlus size={16} /></button>
              <button onClick={() => setMode('poll')} className={`rounded p-1.5 transition ${mode === 'poll' ? 'text-red-400' : 'text-neutral-500 hover:text-white'}`}><BarChart3 size={16} /></button>
            </div>
            <div className="flex gap-2">
              <button onClick={reset} className="rounded-full px-3 py-1.5 text-xs text-neutral-400 hover:bg-neutral-800">Cancel</button>
              <button onClick={handlePost} disabled={posting} className="flex items-center gap-1.5 rounded-full bg-red-500 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-red-600 disabled:opacity-50">
                {posting ? <Loader2 size={12} className="animate-spin" /> : <Send size={12} />} Post
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
