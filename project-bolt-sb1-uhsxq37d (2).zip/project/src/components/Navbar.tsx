import { useState, useRef, useEffect } from 'react';
import { Menu, Search, Upload, Bell, LogOut, User as UserIcon } from 'lucide-react';
import { Logo } from './Logo';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { SearchSuggestions } from './SearchSuggestions';

interface NavbarProps {
  onToggleSidebar: () => void;
  onOpenAuth: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onNavigate: (path: string) => void;
}

export function Navbar({ onToggleSidebar, onOpenAuth, searchQuery, onSearchChange, onNavigate }: NavbarProps) {
  const { user, profile, signOut } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const menuRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  useEffect(() => {
    if (!user) return;
    const fetchUnread = async () => {
      const { count } = await supabase.from('notifications').select('*', { count: 'exact', head: true }).eq('user_id', user.id).eq('is_read', false);
      setUnreadCount(count ?? 0);
    };
    fetchUnread();
    const interval = setInterval(fetchUnread, 30000);
    return () => clearInterval(interval);
  }, [user]);

  const doSearch = (q: string) => {
    onSearchChange(q);
    onNavigate(`/search?q=${encodeURIComponent(q)}`);
    if (user) {
      supabase.from('search_history').upsert({ user_id: user.id, query: q }, { onConflict: 'user_id,query' }).then(() => {});
    }
  };

  return (
    <header className="sticky top-0 z-50 flex h-14 items-center justify-between gap-2 border-b border-neutral-800 bg-neutral-950 px-2 sm:px-4">
      <div className="flex items-center gap-2 sm:gap-4">
        <button onClick={onToggleSidebar} className="rounded-full p-2 text-neutral-300 transition hover:bg-neutral-800" aria-label="Menu"><Menu size={20} /></button>
        <button onClick={() => onNavigate('/')} className="flex items-center gap-2">
          <Logo size={28} />
          <span className="text-lg font-extrabold tracking-tight text-white sm:text-xl">RIZER</span>
        </button>
      </div>

      <div className="flex flex-1 max-w-xl items-center justify-center px-2 sm:px-8">
        <div className="relative w-full max-w-md">
          <div className="flex w-full items-center">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              onFocus={() => { if (user) { /* trigger suggestions */ } }}
              onKeyDown={(e) => { if (e.key === 'Enter' && searchQuery.trim()) doSearch(searchQuery.trim()); }}
              placeholder="Search videos..."
              className="w-full rounded-l-full border border-neutral-700 bg-neutral-900 px-4 py-1.5 text-sm text-white outline-none transition focus:border-neutral-500"
            />
            <button onClick={() => { if (searchQuery.trim()) doSearch(searchQuery.trim()); }} className="rounded-r-full border border-l-0 border-neutral-700 bg-neutral-800 px-4 py-1.5 text-neutral-300 transition hover:bg-neutral-700">
              <Search size={18} />
            </button>
          </div>
          <SearchSuggestions query={searchQuery} onNavigate={onNavigate} onSearch={doSearch} />
        </div>
      </div>

      <div className="flex items-center gap-1 sm:gap-2">
        {user ? (
          <>
            <button onClick={() => onNavigate('/upload')} className="flex items-center gap-1.5 rounded-full bg-neutral-800 px-3 py-1.5 text-sm font-medium text-white transition hover:bg-neutral-700">
              <Upload size={18} /><span className="hidden sm:inline">Upload</span>
            </button>

            {/* Notifications */}
            <div className="relative" ref={notifRef}>
              <button onClick={() => { setNotifOpen(!notifOpen); if (!notifOpen) onNavigate('/notifications'); }} className="relative rounded-full p-2 text-neutral-300 transition hover:bg-neutral-800">
                <Bell size={20} />
                {unreadCount > 0 && (
                  <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-xs font-bold text-white">{unreadCount > 9 ? '9+' : unreadCount}</span>
                )}
              </button>
            </div>

            <div className="relative" ref={menuRef}>
              <button onClick={() => setMenuOpen(!menuOpen)} className="flex h-8 w-8 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-red-500 to-orange-500 text-sm font-bold text-white">
                {profile?.avatar_url ? <img src={profile.avatar_url} alt="avatar" className="h-full w-full object-cover" /> : (profile?.display_name?.[0] ?? user.email?.[0] ?? 'U').toUpperCase()}
              </button>
              {menuOpen && (
                <div className="absolute right-0 mt-2 w-56 overflow-hidden rounded-lg border border-neutral-700 bg-neutral-900 shadow-xl">
                  <div className="border-b border-neutral-800 px-4 py-3">
                    <p className="truncate text-sm font-medium text-white">{profile?.display_name}</p>
                    <p className="truncate text-xs text-neutral-400">@{profile?.username}</p>
                  </div>
                  <button onClick={() => { setMenuOpen(false); onNavigate(`/channel/${user.id}`); }} className="flex w-full items-center gap-3 px-4 py-2.5 text-sm text-neutral-200 transition hover:bg-neutral-800"><UserIcon size={16} /> My Channel</button>
                  <button onClick={() => { setMenuOpen(false); onNavigate('/playlists'); }} className="flex w-full items-center gap-3 px-4 py-2.5 text-sm text-neutral-200 transition hover:bg-neutral-800"><UserIcon size={16} /> My Playlists</button>
                  <button onClick={() => { setMenuOpen(false); signOut(); onNavigate('/'); }} className="flex w-full items-center gap-3 px-4 py-2.5 text-sm text-neutral-200 transition hover:bg-neutral-800"><LogOut size={16} /> Sign Out</button>
                </div>
              )}
            </div>
          </>
        ) : (
          <button onClick={onOpenAuth} className="flex items-center gap-1.5 rounded-full border border-neutral-700 px-3 py-1.5 text-sm font-medium text-white transition hover:bg-neutral-800">
            <UserIcon size={16} /><span>Sign In</span>
          </button>
        )}
      </div>
    </header>
  );
}
