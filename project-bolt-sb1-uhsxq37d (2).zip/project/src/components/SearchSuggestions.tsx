import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Search, Clock, X, TrendingUp } from 'lucide-react';
import type { SearchHistoryItem } from '@/types';

interface SearchSuggestionsProps {
  query: string;
  onNavigate: (path: string) => void;
  onSearch: (q: string) => void;
}

export function SearchSuggestions({ query, onNavigate, onSearch }: SearchSuggestionsProps) {
  const { user } = useAuth();
  const [suggestions, setSuggestions] = useState<SearchHistoryItem[]>([]);
  const [show, setShow] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const fetchHistory = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('search_history')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(8);
    setSuggestions((data ?? []) as SearchHistoryItem[]);
  }, [user]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setShow(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const deleteHistory = async (id: string) => {
    await supabase.from('search_history').delete().eq('id', id);
    setSuggestions((prev) => prev.filter((s) => s.id !== id));
  };

  const filtered = query.trim()
    ? suggestions.filter((s) => s.query.toLowerCase().includes(query.toLowerCase()))
    : suggestions;

  if (!show || filtered.length === 0) return null;

  return (
    <div ref={ref} className="absolute left-0 right-0 top-full z-50 mt-1 overflow-hidden rounded-lg border border-neutral-700 bg-neutral-900 shadow-xl">
      {query.trim() && (
        <button
          onClick={() => { onSearch(query.trim()); setShow(false); }}
          className="flex w-full items-center gap-3 px-4 py-2.5 text-sm text-neutral-200 transition hover:bg-neutral-800"
        >
          <Search size={14} className="text-neutral-500" />
          Search for "<span className="text-white">{query.trim()}</span>"
        </button>
      )}
      {!query.trim() && (
        <div className="px-4 py-2 text-xs font-medium text-neutral-500 flex items-center gap-1.5">
          <TrendingUp size={12} /> Recent searches
        </div>
      )}
      {filtered.map((item) => (
        <div key={item.id} className="flex items-center">
          <button
            onClick={() => { onSearch(item.query); setShow(false); }}
            className="flex flex-1 items-center gap-3 px-4 py-2.5 text-sm text-neutral-200 transition hover:bg-neutral-800"
          >
            <Clock size={14} className="text-neutral-500" />
            {item.query}
          </button>
          <button onClick={() => deleteHistory(item.id)} className="px-3 text-neutral-600 transition hover:text-red-400">
            <X size={14} />
          </button>
        </div>
      ))}
    </div>
  );
}
