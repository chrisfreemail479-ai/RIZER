import { PlayCircle } from 'lucide-react';
import type { VideoWithDetails } from '@/types';
import { formatViews, timeAgo, getYouTubeThumbnail } from '@/lib/utils';

interface VideoCardProps {
  video: VideoWithDetails;
  onNavigate: (path: string) => void;
}

export function VideoCard({ video, onNavigate }: VideoCardProps) {
  const thumbnail =
    video.thumbnail_url ||
    (video.youtube_id ? getYouTubeThumbnail(video.youtube_id) : null);

  return (
    <div
      onClick={() => onNavigate(`/watch/${video.id}`)}
      className="group cursor-pointer"
    >
      <div className="relative aspect-video overflow-hidden rounded-xl bg-neutral-800">
        {thumbnail ? (
          <img
            src={thumbnail}
            alt={video.title}
            className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-neutral-800 to-neutral-900">
            <PlayCircle size={48} className="text-neutral-600" />
          </div>
        )}
        <div className="absolute inset-0 bg-black/0 transition group-hover:bg-black/10" />
      </div>
      <div className="mt-2 flex gap-3">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onNavigate(`/channel/${video.user_id}`);
          }}
          className="mt-0.5 h-9 w-9 flex-shrink-0 overflow-hidden rounded-full bg-gradient-to-br from-red-500 to-orange-500"
        >
          {video.profiles?.avatar_url ? (
            <img src={video.profiles.avatar_url} alt="avatar" className="h-full w-full object-cover" />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-sm font-bold text-white">
              {(video.profiles?.display_name?.[0] ?? 'U').toUpperCase()}
            </div>
          )}
        </button>
        <div className="min-w-0 flex-1">
          <h3 className="line-clamp-2 text-sm font-medium text-white transition group-hover:text-neutral-200">
            {video.title}
          </h3>
          <p className="mt-1 text-xs text-neutral-400">{video.profiles?.display_name}</p>
          <p className="text-xs text-neutral-400">
            {formatViews(video.views)} • {timeAgo(video.created_at)}
          </p>
        </div>
      </div>
    </div>
  );
}
