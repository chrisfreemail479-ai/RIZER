import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { VideoWithDetails } from '@/types';
import { ListPlus, X, Lock, Globe } from 'lucide-react';
import type { Playlist } from '@/types';

interface AddToPlaylistModalProps {
  video: VideoWithDetails;
  open: boolean;
  onClose: () => void;
}

export function AddToPlaylistModal({ video, open, onClose }: AddToPlaylistModalProps) {
  const { user } = useAuth();
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPublic, setNewPublic] = useState(false);
  const [loading, setLoading] = useState(false);

  if (!open || !user) return null;

  const fetchPlaylists = async () => {
    setLoading(true);
    const { data } = await supabase.from('playlists').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
    setPlaylists((data ?? []) as Playlist[]);
    setLoading(false);
  };

  if (playlists.length === 0 && !loading && !showCreate) fetchPlaylists();

  const toggleVideo = async (playlistId: string) => {
    const { data: existing } = await supabase
      .from('playlist_items')
      .select('id')
      .eq('playlist_id', playlistId)
      .eq('video_id', video.id)
      .maybeSingle();

    if (existing) {
      await supabase.from('playlist_items').delete().eq('id', existing.id);
    } else {
      const { data: count } = await supabase.from('playlist_items').select('id', { count: 'exact', head: true }).eq('playlist_id', playlistId);
      await supabase.from('playlist_items').insert({ playlist_id: playlistId, video_id: video.id, position: count ?? 0 });
    }
  };

  const createPlaylist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    const { data } = await supabase.from('playlists').insert({ user_id: user.id, name: newName.trim(), is_public: newPublic }).select('*').single();
    if (data) {
      setPlaylists((prev) => [data as Playlist, ...prev]);
      setNewName(''); setNewPublic(false); setShowCreate(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60" onClick={onClose}>
      <div className="w-full max-w-md rounded-xl border border-neutral-800 bg-neutral-950 p-5" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-base font-bold text-white">Save to playlist</h2>
          <button onClick={onClose} className="text-neutral-400 hover:text-white"><X size={18} /></button>
        </div>

        {showCreate ? (
          <form onSubmit={createPlaylist} className="space-y-3">
            <input type="text" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Playlist name" autoFocus className="w-full rounded-lg border border-neutral-700 bg-neutral-900 px-3 py-2 text-sm text-white outline-none focus:border-neutral-500" required />
            <label className="flex items-center gap-2 text-sm text-neutral-300">
              <input type="checkbox" checked={newPublic} onChange={(e) => setNewPublic(e.target.checked)} />
              {newPublic ? <Globe size={14} className="text-green-400" /> : <Lock size={14} />}
              Make public
            </label>
            <div className="flex gap-2">
              <button type="button" onClick={() => setShowCreate(false)} className="rounded-lg px-3 py-2 text-sm text-neutral-400 hover:bg-neutral-800">Cancel</button>
              <button type="submit" className="rounded-lg bg-red-500 px-3 py-2 text-sm font-medium text-white hover:bg-red-600">Create</button>
            </div>
          </form>
        ) : (
          <>
            <div className="max-h-64 space-y-2 overflow-y-auto">
              {playlists.map((pl) => (
                <button key={pl.id} onClick={() => toggleVideo(pl.id)} className="flex w-full items-center gap-3 rounded-lg p-2 text-left transition hover:bg-neutral-900">
                  <div className={`flex h-5 w-5 items-center justify-center rounded border ${pl.is_public ? 'border-green-500/50' : 'border-neutral-600'}`}>
                    {pl.is_public && <Globe size={12} className="text-green-400" />}
                  </div>
                  <span className="flex-1 text-sm text-neutral-200">{pl.name}</span>
                  <span className="text-xs text-neutral-500">{pl.is_public ? 'Public' : 'Private'}</span>
                </button>
              ))}
            </div>
            <button onClick={() => setShowCreate(true)} className="mt-3 flex w-full items-center gap-2 rounded-lg border border-dashed border-neutral-700 p-2 text-sm text-neutral-400 transition hover:bg-neutral-900 hover:text-white">
              <ListPlus size={16} /> Create new playlist
            </button>
          </>
        )}
      </div>
    </div>
  );
}
