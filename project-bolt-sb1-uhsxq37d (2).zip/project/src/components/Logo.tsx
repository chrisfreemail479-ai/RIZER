interface LogoProps {
  size?: number;
  className?: string;
}

export function Logo({ size = 32, className = '' }: LogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <linearGradient id="rizerGrad" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FF3D3D" />
          <stop offset="1" stopColor="#FF6B2C" />
        </linearGradient>
      </defs>
      <rect width="48" height="48" rx="12" fill="url(#rizerGrad)" />
      <path
        d="M19 16.5C19 15.7 19.84 15.21 20.54 15.58L31.5 21.58C32.22 21.97 32.22 23.03 31.5 23.42L20.54 29.42C19.84 29.79 19 29.3 19 28.5V16.5Z"
        fill="white"
      />
      <rect x="10" y="10" width="28" height="28" rx="8" stroke="white" strokeOpacity="0.25" strokeWidth="2" />
    </svg>
  );
}

export function LogoWordmark({ size = 28 }: { size?: number }) {
  return (
    <div className="flex items-center gap-2">
      <Logo size={size} />
      <span className="text-xl font-extrabold tracking-tight text-white">
        RIZER
      </span>
    </div>
  );
}
