import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Post, PollOption } from '@/types';
import { timeAgo, formatCount } from '@/lib/utils';
import { ThumbsUp, Trash2, BarChart3 } from 'lucide-react';

interface PostListProps {
  userId: string;
  onNavigate: (path: string) => void;
}

export function PostList({ userId, onNavigate }: PostListProps) {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [votedOptions, setVotedOptions] = useState<Set<string>>(new Set());

  const fetchPosts = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('posts')
      .select(`
        *,
        profiles:user_id (id, username, display_name, avatar_url),
        poll_options (id, post_id, label, position)
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(20);

    const allPosts = (data ?? []) as unknown as Post[];
    const optionIds = allPosts.flatMap((p) => (p.poll_options ?? []).map((o) => o.id));

    let voteCounts: Record<string, number> = {};
    let myVotes: Set<string> = new Set();
    if (optionIds.length > 0) {
      const { data: votes } = await supabase.from('poll_votes').select('option_id, user_id').in('option_id', optionIds);
      (votes ?? []).forEach((v) => {
        voteCounts[v.option_id] = (voteCounts[v.option_id] ?? 0) + 1;
        if (user && v.user_id === user.id) myVotes.add(v.option_id);
      });
    }

    allPosts.forEach((p) => {
      (p.poll_options ?? []).forEach((o) => {
        o.vote_count = voteCounts[o.id] ?? 0;
        o.voted_by_me = myVotes.has(o.id);
      });
    });

    setPosts(allPosts);
    setVotedOptions(myVotes);
    setLoading(false);
  }, [userId, user]);

  useEffect(() => { fetchPosts(); }, [fetchPosts]);

  const vote = async (optionId: string, postId: string) => {
    if (!user) return;
    if (votedOptions.has(optionId)) {
      await supabase.from('poll_votes').delete().eq('option_id', optionId).eq('user_id', user.id);
      setVotedOptions((prev) => { const n = new Set(prev); n.delete(optionId); return n; });
      setPosts((prev) => prev.map((p) => p.id === postId ? {
        ...p,
        poll_options: (p.poll_options ?? []).map((o) => o.id === optionId ? { ...o, vote_count: (o.vote_count ?? 1) - 1, voted_by_me: false } : o)
      } : p));
    } else {
      await supabase.from('poll_votes').insert({ option_id: optionId, user_id: user.id });
      setVotedOptions((prev) => new Set(prev).add(optionId));
      setPosts((prev) => prev.map((p) => p.id === postId ? {
        ...p,
        poll_options: (p.poll_options ?? []).map((o) => o.id === optionId ? { ...o, vote_count: (o.vote_count ?? 0) + 1, voted_by_me: true } : o)
      } : p));
    }
  };

  const deletePost = async (postId: string) => {
    await supabase.from('posts').delete().eq('id', postId).eq('user_id', user!.id);
    setPosts((prev) => prev.filter((p) => p.id !== postId));
  };

  if (loading) {
    return <div className="flex justify-center py-8"><div className="h-6 w-6 animate-spin rounded-full border-2 border-neutral-700 border-t-red-500" /></div>;
  }

  if (posts.length === 0) {
    return <p className="py-8 text-center text-sm text-neutral-500">No posts yet.</p>;
  }

  return (
    <div className="space-y-4">
      {posts.map((post) => {
        const totalVotes = (post.poll_options ?? []).reduce((sum, o) => sum + (o.vote_count ?? 0), 0);
        return (
          <div key={post.id} className="rounded-xl border border-neutral-800 bg-neutral-900 p-4">
            <div className="flex items-center gap-2">
              <button onClick={() => onNavigate(`/channel/${post.user_id}`)} className="h-8 w-8 overflow-hidden rounded-full bg-gradient-to-br from-red-500 to-orange-500">
                {post.profiles?.avatar_url ? (
                  <img src={post.profiles.avatar_url} alt="avatar" className="h-full w-full object-cover" />
                ) : (
                  <div className="flex h-full w-full items-center justify-center text-xs font-bold text-white">{(post.profiles?.display_name?.[0] ?? 'U').toUpperCase()}</div>
                )}
              </button>
              <div className="flex-1">
                <span className="text-sm font-medium text-white">{post.profiles?.display_name}</span>
                <span className="ml-2 text-xs text-neutral-500">{timeAgo(post.created_at)}</span>
              </div>
              {post.user_id === user?.id && (
                <button onClick={() => deletePost(post.id)} className="text-neutral-600 transition hover:text-red-400"><Trash2 size={14} /></button>
              )}
            </div>

            {post.body && <p className="mt-3 text-sm text-neutral-200">{post.body}</p>}

            {post.content_type === 'image' && post.image_url && (
              <img src={post.image_url} alt="post" className="mt-3 max-h-96 w-full rounded-lg object-cover" />
            )}

            {post.content_type === 'poll' && post.poll_options && (
              <div className="mt-3 space-y-2">
                {post.poll_options.sort((a, b) => a.position - b.position).map((opt) => {
                  const pct = totalVotes > 0 ? Math.round(((opt.vote_count ?? 0) / totalVotes) * 100) : 0;
                  const voted = votedOptions.has(opt.id);
                  return (
                    <button
                      key={opt.id}
                      onClick={() => vote(opt.id, post.id)}
                      className="relative w-full overflow-hidden rounded-lg border border-neutral-700 px-3 py-2 text-left text-sm transition hover:border-neutral-600"
                    >
                      {voted && (
                        <div className="absolute inset-0 bg-red-500/15" style={{ width: `${pct}%` }} />
                      )}
                      <div className="relative flex items-center justify-between">
                        <span className={voted ? 'text-white' : 'text-neutral-200'}>{opt.label}</span>
                        <span className="text-xs text-neutral-400">
                          {voted && `${pct}% • `}{formatCount(opt.vote_count ?? 0)}
                        </span>
                      </div>
                    </button>
                  );
                })}
                <p className="text-xs text-neutral-500">{formatCount(totalVotes)} {totalVotes === 1 ? 'vote' : 'votes'}</p>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
