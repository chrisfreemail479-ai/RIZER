import { Home, Flame, Clock, ThumbsUp, User as UserIcon, BarChart3, Settings, Zap, Bell, ListVideo, X } from 'lucide-react';

interface SidebarProps {
  open: boolean;
  onClose: () => void;
  onNavigate: (path: string) => void;
  currentPath: string;
}

const sections = [
  { label: 'Home', icon: Home, path: '/' },
  { label: 'Rezzers', icon: Zap, path: '/rezzers' },
  { label: 'Trending', icon: Flame, path: '/trending' },
  { label: 'Notifications', icon: Bell, path: '/notifications' },
  { label: 'Playlists', icon: ListVideo, path: '/playlists' },
  { label: 'History', icon: Clock, path: '/history' },
  { label: 'Liked', icon: ThumbsUp, path: '/liked' },
  { label: 'My Channel', icon: UserIcon, path: '/my-channel' },
  { label: 'Analytics', icon: BarChart3, path: '/analytics' },
  { label: 'Customize Channel', icon: Settings, path: '/customize' },
];

export function Sidebar({ open, onClose, onNavigate, currentPath }: SidebarProps) {
  return (
    <>
      {open && (
        <div className="fixed inset-0 z-30 bg-black/50 md:hidden" onClick={onClose} />
      )}
      <aside
        className={`fixed left-0 top-14 z-30 h-[calc(100vh-3.5rem)] w-56 overflow-y-auto border-r border-neutral-800 bg-neutral-950 transition-transform duration-200 md:static md:top-0 md:h-full md:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="md:hidden">
          <button onClick={onClose} className="absolute right-3 top-3 text-neutral-400">
            <X size={20} />
          </button>
        </div>
        <nav className="flex flex-col gap-1 p-3">
          {sections.map((item) => {
            const Icon = item.icon;
            const active = currentPath === item.path || (item.path === '/' && currentPath === '/');
            return (
              <button
                key={item.path}
                onClick={() => {
                  onNavigate(item.path);
                  if (window.innerWidth < 768) onClose();
                }}
                className={`flex items-center gap-4 rounded-lg px-3 py-2.5 text-sm transition ${
                  active
                    ? 'bg-neutral-800 font-medium text-white'
                    : 'text-neutral-300 hover:bg-neutral-900'
                }`}
              >
                <Icon size={20} />
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="mt-2 border-t border-neutral-800 p-3">
          <p className="px-3 text-xs text-neutral-500">
            RIZER — Watch, upload, and share videos with the world.
          </p>
        </div>
      </aside>
    </>
  );
}
