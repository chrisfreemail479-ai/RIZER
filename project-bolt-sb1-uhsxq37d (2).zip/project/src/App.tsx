import { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { Navbar } from '@/components/Navbar';
import { Sidebar } from '@/components/Sidebar';
import { AuthModal } from '@/components/AuthModal';
import { HomePage } from '@/pages/HomePage';
import { WatchPage } from '@/pages/WatchPage';
import { UploadPage } from '@/pages/UploadPage';
import { ChannelPage } from '@/pages/ChannelPage';
import { CustomizePage } from '@/pages/CustomizePage';
import { AnalyticsPage } from '@/pages/AnalyticsPage';
import { SearchPage } from '@/pages/SearchPage';
import { HistoryPage } from '@/pages/HistoryPage';
import { TrendingPage } from '@/pages/TrendingPage';
import { LikedPage } from '@/pages/LikedPage';
import { RezzerPage } from '@/pages/RezzerPage';
import { NotificationsPage } from '@/pages/NotificationsPage';
import { PlaylistsPage } from '@/pages/PlaylistsPage';

function AppContent() {
  const { user, loading } = useAuth();
  const [route, setRoute] = useState(window.location.hash.slice(1) || '/');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const handleHashChange = () => {
      setRoute(window.location.hash.slice(1) || '/');
      window.scrollTo(0, 0);
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigate = useCallback((path: string) => {
    window.location.hash = path;
    setRoute(path);
    window.scrollTo(0, 0);
  }, []);

  const openAuth = useCallback(() => setAuthModalOpen(true), []);

  // Parse route
  let page: React.ReactNode;
  let currentPath: string;

  if (route.startsWith('/watch/')) {
    const videoId = route.slice('/watch/'.length);
    currentPath = '/watch';
    page = <WatchPage videoId={videoId} onNavigate={navigate} onOpenAuth={openAuth} />;
  } else if (route === '/upload') {
    currentPath = '/upload';
    page = <UploadPage onNavigate={navigate} onOpenAuth={openAuth} />;
  } else if (route === '/customize') {
    currentPath = '/customize';
    page = <CustomizePage onNavigate={navigate} />;
  } else if (route === '/analytics') {
    currentPath = '/analytics';
    page = <AnalyticsPage onNavigate={navigate} />;
  } else if (route.startsWith('/channel/')) {
    const userId = route.slice('/channel/'.length);
    currentPath = `/channel/${userId}`;
    page = <ChannelPage userId={userId} onNavigate={navigate} currentUserId={user?.id ?? null} onOpenAuth={openAuth} />;
  } else if (route.startsWith('/search')) {
    const params = new URLSearchParams(route.split('?')[1] || '');
    const q = params.get('q') || '';
    currentPath = '/search';
    page = <SearchPage query={q} onNavigate={navigate} />;
  } else if (route === '/rezzers') {
    currentPath = '/rezzers';
    page = <RezzerPage onNavigate={navigate} onOpenAuth={openAuth} />;
  } else if (route === '/notifications') {
    currentPath = '/notifications';
    page = <NotificationsPage onNavigate={navigate} />;
  } else if (route === '/playlists') {
    currentPath = '/playlists';
    page = <PlaylistsPage onNavigate={navigate} onOpenAuth={openAuth} />;
  } else if (route === '/trending') {
    currentPath = '/trending';
    page = <TrendingPage onNavigate={navigate} />;
  } else if (route === '/history') {
    currentPath = '/history';
    page = <HistoryPage onNavigate={navigate} onOpenAuth={openAuth} />;
  } else if (route === '/liked') {
    currentPath = '/liked';
    page = <LikedPage onNavigate={navigate} onOpenAuth={openAuth} />;
  } else {
    currentPath = '/';
    page = <HomePage onNavigate={navigate} />;
  }

  // Redirect /my-channel to actual channel
  if (route === '/my-channel' && user) {
    navigate(`/channel/${user.id}`);
  }

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-neutral-950">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-neutral-700 border-t-red-500" />
      </div>
    );
  }

  return (
    <div className="flex h-screen flex-col bg-neutral-950">
      <Navbar
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        onOpenAuth={openAuth}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onNavigate={navigate}
      />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          open={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          onNavigate={navigate}
          currentPath={currentPath}
        />
        <main className="flex-1 overflow-y-auto">
          {page}
        </main>
      </div>
      <AuthModal open={authModalOpen} onClose={() => setAuthModalOpen(false)} />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
