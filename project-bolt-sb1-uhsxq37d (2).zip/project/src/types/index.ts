export interface Profile {
  id: string;
  username: string;
  display_name: string;
  avatar_url: string | null;
  bio: string | null;
  banner_url: string | null;
  created_at: string;
}

export interface Video {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  video_type: 'file' | 'youtube';
  video_url: string | null;
  youtube_id: string | null;
  thumbnail_url: string | null;
  views: number;
  is_short: boolean;
  music_title: string | null;
  clip_duration: number | null;
  created_at: string;
  profiles?: Profile;
}

export interface Comment {
  id: string;
  video_id: string;
  user_id: string;
  content: string;
  parent_id: string | null;
  created_at: string;
  profiles?: Profile;
  like_count?: number;
  liked_by_me?: boolean;
  replies?: Comment[];
}

export interface VideoWithDetails extends Video {
  like_count?: number;
  comment_count?: number;
  liked_by_me?: boolean;
}

export interface Post {
  id: string;
  user_id: string;
  content_type: 'text' | 'image' | 'poll';
  body: string | null;
  image_url: string | null;
  created_at: string;
  profiles?: Profile;
  poll_options?: PollOption[];
}

export interface PollOption {
  id: string;
  post_id: string;
  label: string;
  position: number;
  vote_count?: number;
  voted_by_me?: boolean;
}

export interface Playlist {
  id: string;
  user_id: string;
  name: string;
  description: string | null;
  is_public: boolean;
  created_at: string;
  profiles?: Profile;
  item_count?: number;
}

export interface PlaylistItem {
  id: string;
  playlist_id: string;
  video_id: string;
  position: number;
  added_at: string;
  videos?: VideoWithDetails;
}

export interface AppNotification {
  id: string;
  user_id: string;
  actor_id: string | null;
  type: 'subscribe' | 'comment' | 'like' | 'reply' | 'video';
  entity_id: string | null;
  message: string | null;
  is_read: boolean;
  created_at: string;
  actor?: Profile;
}

export interface SearchHistoryItem {
  id: string;
  user_id: string;
  query: string;
  created_at: string;
}
