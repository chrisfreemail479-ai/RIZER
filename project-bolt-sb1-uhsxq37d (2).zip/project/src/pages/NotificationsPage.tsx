import { useState, useEffect, useCallback } from 'react';
import { Bell, Trash2, UserPlus, MessageCircle, ThumbsUp, CornerDownRight, Video } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { AppNotification } from '@/types';
import { timeAgo } from '@/lib/utils';

interface NotificationsPageProps {
  onNavigate: (path: string) => void;
}

export function NotificationsPage({ onNavigate }: NotificationsPageProps) {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchNotifications = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('notifications')
      .select(`
        *,
        actor:actor_id (id, username, display_name, avatar_url)
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50);
    setNotifications((data ?? []) as unknown as AppNotification[]);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  const markAllRead = async () => {
    if (!user) return;
    await supabase.from('notifications').update({ is_read: true }).eq('user_id', user.id).eq('is_read', false);
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
  };

  const deleteNotification = async (id: string) => {
    await supabase.from('notifications').delete().eq('id', id);
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'subscribe': return <UserPlus size={18} className="text-blue-400" />;
      case 'comment': return <MessageCircle size={18} className="text-green-400" />;
      case 'like': return <ThumbsUp size={18} className="text-red-400" />;
      case 'reply': return <CornerDownRight size={18} className="text-orange-400" />;
      case 'video': return <Video size={18} className="text-purple-400" />;
      default: return <Bell size={18} className="text-neutral-400" />;
    }
  };

  const handleClick = (n: AppNotification) => {
    if (!n.is_read) {
      supabase.from('notifications').update({ is_read: true }).eq('id', n.id).then(() => {});
      setNotifications((prev) => prev.map((item) => item.id === n.id ? { ...item, is_read: true } : item));
    }
    if (n.type === 'subscribe' && n.actor_id) onNavigate(`/channel/${n.actor_id}`);
    else if ((n.type === 'comment' || n.type === 'like' || n.type === 'reply' || n.type === 'video') && n.entity_id) onNavigate(`/watch/${n.entity_id}`);
  };

  if (!user) {
    return <div className="flex items-center justify-center py-20 text-neutral-400">Sign in to see notifications.</div>;
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-6 sm:px-6">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-bold text-white">Notifications</h1>
        {notifications.some((n) => !n.is_read) && (
          <button onClick={markAllRead} className="text-sm text-neutral-400 transition hover:text-white">Mark all read</button>
        )}
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-2 border-neutral-700 border-t-red-500" /></div>
      ) : notifications.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Bell size={48} className="text-neutral-600" />
          <p className="mt-4 text-sm text-neutral-500">No notifications yet</p>
        </div>
      ) : (
        <div className="space-y-2">
          {notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => handleClick(n)}
              className={`flex cursor-pointer items-start gap-3 rounded-lg p-3 transition hover:bg-neutral-900 ${!n.is_read ? 'bg-neutral-900/50' : ''}`}
            >
              <div className="mt-0.5 flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-neutral-800">
                {getIcon(n.type)}
              </div>
              <div className="flex-1">
                <p className="text-sm text-neutral-200">
                  {n.actor?.display_name && <span className="font-medium text-white">{n.actor.display_name} </span>}
                  {n.message || 'New notification'}
                </p>
                <p className="mt-0.5 text-xs text-neutral-500">{timeAgo(n.created_at)}</p>
              </div>
              {!n.is_read && <div className="mt-2 h-2 w-2 flex-shrink-0 rounded-full bg-red-500" />}
              <button
                onClick={(e) => { e.stopPropagation(); deleteNotification(n.id); }}
                className="text-neutral-600 transition hover:text-red-400"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
