import { useState, useRef, useCallback } from 'react';
import { Upload, Link2, FileVideo, Image, X, Loader2, Youtube, Camera, Music, Clock, Search } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { extractYouTubeId, getYouTubeThumbnail } from '@/lib/utils';

interface UploadPageProps {
  onNavigate: (path: string) => void;
  onOpenAuth: () => void;
}

const CLIP_DURATIONS = [10, 15, 30];

interface AppleMusicTrack {
  trackName: string;
  artistName: string;
  artworkUrl: string;
  previewUrl: string;
  trackId: number;
}

export function UploadPage({ onNavigate, onOpenAuth }: UploadPageProps) {
  const { user } = useAuth();
  const [uploadType, setUploadType] = useState<'file' | 'youtube' | 'camera'>('file');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [thumbFile, setThumbFile] = useState<File | null>(null);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);
  const [thumbPreview, setThumbPreview] = useState<string | null>(null);
  const [autoThumbUrl, setAutoThumbUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [isShort, setIsShort] = useState(false);
  const [musicTitle, setMusicTitle] = useState<string | null>(null);
  const [clipDuration, setClipDuration] = useState<number | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraRecording, setCameraRecording] = useState(false);
  const [musicQuery, setMusicQuery] = useState('');
  const [musicResults, setMusicResults] = useState<AppleMusicTrack[]>([]);
  const [musicSearching, setMusicSearching] = useState(false);
  const [selectedTrack, setSelectedTrack] = useState<AppleMusicTrack | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const thumbInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const musicTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const songAudioRef = useRef<HTMLAudioElement | null>(null);
  const clipTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <FileVideo size={48} className="text-neutral-600" />
        <p className="mt-4 text-lg font-medium text-neutral-300">Sign in to upload</p>
        <p className="mt-1 text-sm text-neutral-500">You need an account to post videos on RIZER.</p>
        <button onClick={onOpenAuth} className="mt-4 rounded-lg bg-gradient-to-r from-red-500 to-orange-500 px-5 py-2 text-sm font-semibold text-white transition hover:from-red-600 hover:to-orange-600">Sign In</button>
      </div>
    );
  }

  const generateThumbnail = (videoUrl: string): Promise<string> => {
    return new Promise((resolve) => {
      const video = document.createElement('video');
      video.src = videoUrl;
      video.crossOrigin = 'anonymous';
      video.muted = true;
      video.playsInline = true;
      video.addEventListener('loadeddata', () => {
        video.currentTime = Math.min(1, video.duration / 3);
      });
      video.addEventListener('seeked', () => {
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 360;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          try {
            const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
            resolve(dataUrl);
          } catch {
            resolve('');
          }
        } else {
          resolve('');
        }
      });
      video.load();
    });
  };

  const dataUrlToBlob = (dataUrl: string): Blob => {
    const arr = dataUrl.split(',');
    const mime = arr[0].match(/:(.*?);/)?.[1] || 'image/jpeg';
    const bstr = atob(arr[1]);
    const u8 = new Uint8Array(bstr.length);
    for (let i = 0; i < bstr.length; i++) u8[i] = bstr.charCodeAt(i);
    return new Blob([u8], { type: mime });
  };

  const handleVideoFile = async (file: File) => {
    if (file.size > 100 * 1024 * 1024) { setError('Video file must be under 100MB'); return; }
    setVideoFile(file);
    const preview = URL.createObjectURL(file);
    setVideoPreview(preview);
    setError(null);
    if (!title) setTitle(file.name.replace(/\.[^.]+$/, ''));
    // Auto-generate thumbnail from video frame
    try {
      const thumbDataUrl = await generateThumbnail(preview);
      if (thumbDataUrl) {
        setAutoThumbUrl(thumbDataUrl);
      }
    } catch { /* ignore */ }
  };

  const handleThumbFile = (file: File) => {
    if (file.size > 5 * 1024 * 1024) { setError('Thumbnail must be under 5MB'); return; }
    setThumbFile(file);
    setThumbPreview(URL.createObjectURL(file));
    setAutoThumbUrl(null);
    setError(null);
  };

  // Camera capture
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: true });
      setCameraStream(stream);
      setUploadType('camera');
      setIsShort(true);
      setTimeout(() => {
        if (videoRef.current) { videoRef.current.srcObject = stream; videoRef.current.play(); }
      }, 100);
    } catch {
      setError('Could not access camera. Make sure to allow camera permissions.');
    }
  };

  const stopCamera = () => {
    if (cameraStream) { cameraStream.getTracks().forEach((t) => t.stop()); setCameraStream(null); }
    setCameraRecording(false);
    if (songAudioRef.current) { songAudioRef.current.pause(); songAudioRef.current = null; }
    if (audioContextRef.current) { audioContextRef.current.close().catch(() => {}); audioContextRef.current = null; }
    if (clipTimerRef.current) { clearTimeout(clipTimerRef.current); clipTimerRef.current = null; }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
  };

  const startRecording = () => {
    chunksRef.current = [];

    let recordStream: MediaStream = cameraStream!;

    // If a song is selected, mix song audio with mic audio
    if (selectedTrack && selectedTrack.previewUrl) {
      try {
        const ac = new AudioContext();
        audioContextRef.current = ac;
        const dest = ac.createMediaStreamDestination();

        // Mic audio
        const micSource = ac.createMediaStreamSource(cameraStream!);
        micSource.connect(dest);

        // Song audio
        const songEl = new Audio(selectedTrack.previewUrl);
        songEl.crossOrigin = 'anonymous';
        songEl.loop = true;
        songAudioRef.current = songEl;
        const songSource = ac.createMediaElementSource(songEl);
        songSource.connect(dest);
        songSource.connect(ac.destination); // also play through speakers
        songEl.play().catch(() => {});

        // Combine video track from camera + mixed audio track
        recordStream = new MediaStream([
          ...cameraStream!.getVideoTracks(),
          ...dest.stream.getAudioTracks(),
        ]);
      } catch {
        // Fallback: just use camera stream as-is
        recordStream = cameraStream!;
      }
    }

    const mr = new MediaRecorder(recordStream);
    mediaRecorderRef.current = mr;
    mr.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
    mr.onstop = async () => {
      // Stop song
      if (songAudioRef.current) { songAudioRef.current.pause(); songAudioRef.current = null; }
      if (audioContextRef.current) { audioContextRef.current.close().catch(() => {}); audioContextRef.current = null; }
      if (clipTimerRef.current) { clearTimeout(clipTimerRef.current); clipTimerRef.current = null; }

      const blob = new Blob(chunksRef.current, { type: 'video/webm' });
      if (blob.size === 0) { setError('Recording was empty. Try again.'); return; }
      const file = new File([blob], `rezzer-${Date.now()}.webm`, { type: 'video/webm' });
      const preview = URL.createObjectURL(file);
      setVideoFile(file);
      setVideoPreview(preview);
      if (!title) setTitle('My Rezzer');
      try {
        const thumbDataUrl = await generateThumbnail(preview);
        if (thumbDataUrl) setAutoThumbUrl(thumbDataUrl);
      } catch { /* ignore */ }
    };
    mr.start();
    setCameraRecording(true);

    // Auto-stop after clip duration
    const duration = (clipDuration ?? 15) * 1000;
    clipTimerRef.current = setTimeout(() => {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      setCameraRecording(false);
    }, duration);
  };

  const stopRecording = () => {
    setCameraRecording(false);
    if (songAudioRef.current) { songAudioRef.current.pause(); songAudioRef.current = null; }
    if (audioContextRef.current) { audioContextRef.current.close().catch(() => {}); audioContextRef.current = null; }
    if (clipTimerRef.current) { clearTimeout(clipTimerRef.current); clipTimerRef.current = null; }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!title.trim()) { setError('Please enter a title'); return; }
    setUploading(true);
    setProgress(0);

    try {
      let videoUrl: string | null = null;
      let thumbnailUrl: string | null = null;
      let youtubeId: string | null = null;

      if (uploadType === 'youtube') {
        youtubeId = extractYouTubeId(youtubeUrl);
        if (!youtubeId) { setError('Invalid YouTube URL.'); setUploading(false); return; }
        thumbnailUrl = getYouTubeThumbnail(youtubeId);
      } else {
        if (!videoFile) { setError('Please select or record a video'); setUploading(false); return; }
        const videoExt = videoFile.name.split('.').pop();
        const videoPath = `${user.id}/${Date.now()}.${videoExt}`;
        const { error: vErr } = await supabase.storage.from('videos').upload(videoPath, videoFile, { cacheControl: '3600', upsert: false });
        if (vErr) throw new Error(`Video upload failed: ${vErr.message}`);
        setProgress(50);
        videoUrl = supabase.storage.from('videos').getPublicUrl(videoPath).data.publicUrl;

        // Use custom thumbnail if provided, otherwise auto-generated
        if (thumbFile) {
          const thumbExt = thumbFile.name.split('.').pop();
          const thumbPath = `${user.id}/${Date.now()}.${thumbExt}`;
          const { error: tErr } = await supabase.storage.from('thumbnails').upload(thumbPath, thumbFile, { cacheControl: '3600', upsert: false });
          if (tErr) throw new Error(`Thumbnail upload failed: ${tErr.message}`);
          thumbnailUrl = supabase.storage.from('thumbnails').getPublicUrl(thumbPath).data.publicUrl;
        } else if (autoThumbUrl) {
          const thumbBlob = dataUrlToBlob(autoThumbUrl);
          const thumbPath = `${user.id}/${Date.now()}.jpg`;
          const { error: tErr } = await supabase.storage.from('thumbnails').upload(thumbPath, thumbBlob, { cacheControl: '3600', upsert: false, contentType: 'image/jpeg' });
          if (!tErr) thumbnailUrl = supabase.storage.from('thumbnails').getPublicUrl(thumbPath).data.publicUrl;
        }
        setProgress(100);
      }

      const { data: videoData, error: dbErr } = await supabase
        .from('videos')
        .insert({
          user_id: user.id, title: title.trim(), description: description.trim() || null,
          video_type: uploadType === 'camera' ? 'file' : uploadType,
          video_url: videoUrl, youtube_id: youtubeId, thumbnail_url: thumbnailUrl,
          is_short: isShort, music_title: isShort ? musicTitle : null, clip_duration: isShort ? clipDuration : null,
        })
        .select('id').single();
      if (dbErr) throw new Error(`Database error: ${dbErr.message}`);
      onNavigate(isShort ? '/rezzers' : `/watch/${videoData.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-4 py-6 sm:px-6">
      <h1 className="mb-6 text-2xl font-bold text-white">Upload a Video</h1>

      {/* Upload type toggle */}
      <div className="mb-6 flex gap-2 rounded-lg bg-neutral-900 p-1">
        <button onClick={() => { setUploadType('file'); stopCamera(); }} className={`flex flex-1 items-center justify-center gap-2 rounded-md py-2.5 text-sm font-medium transition ${uploadType === 'file' ? 'bg-neutral-700 text-white' : 'text-neutral-400 hover:text-neutral-200'}`}><FileVideo size={18} /> Upload File</button>
        <button onClick={() => { setUploadType('youtube'); stopCamera(); }} className={`flex flex-1 items-center justify-center gap-2 rounded-md py-2.5 text-sm font-medium transition ${uploadType === 'youtube' ? 'bg-neutral-700 text-white' : 'text-neutral-400 hover:text-neutral-200'}`}><Youtube size={18} /> YouTube Link</button>
        <button onClick={() => startCamera()} className={`flex flex-1 items-center justify-center gap-2 rounded-md py-2.5 text-sm font-medium transition ${uploadType === 'camera' ? 'bg-neutral-700 text-white' : 'text-neutral-400 hover:text-neutral-200'}`}><Camera size={18} /> <span className="hidden sm:inline">Film</span></button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {uploadType === 'camera' && (
          <div>
            <label className="mb-2 block text-sm font-medium text-neutral-300">Film a Rezzer</label>
            <div className="relative overflow-hidden rounded-xl bg-black" style={{ aspectRatio: '9/16', maxHeight: '500px' }}>
              <video ref={videoRef} className="h-full w-full object-cover" muted playsInline style={{ transform: cameraRecording || !videoPreview ? 'scaleX(-1)' : 'none' }} />
              {!cameraRecording && !videoPreview && (
                <div className="absolute inset-0 flex items-center justify-center text-neutral-500">
                  <div className="text-center">
                    <Camera size={36} className="mx-auto" />
                    <p className="mt-2 text-sm">Camera ready</p>
                  </div>
                </div>
              )}
              {cameraRecording && (
                <div className="absolute left-3 top-3 flex items-center gap-2 rounded-full bg-red-500/80 px-3 py-1 text-xs font-medium text-white">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-white" /> REC
                </div>
              )}
            </div>
            <div className="mt-3 flex gap-2">
              {!cameraRecording ? (
                <button type="button" onClick={startRecording} disabled={!cameraStream} className="rounded-lg bg-red-500 px-4 py-2 text-sm font-medium text-white transition hover:bg-red-600 disabled:opacity-50">Start Recording</button>
              ) : (
                <button type="button" onClick={stopRecording} className="rounded-lg bg-neutral-700 px-4 py-2 text-sm font-medium text-white transition hover:bg-neutral-600">Stop Recording</button>
              )}
              <button type="button" onClick={stopCamera} className="rounded-lg bg-neutral-800 px-4 py-2 text-sm text-neutral-300 transition hover:bg-neutral-700">Cancel</button>
            </div>
            {videoPreview && (
              <div className="mt-3">
                <p className="mb-1 text-xs text-green-400">Recording saved!</p>
                <video src={videoPreview} className="max-h-64 rounded-lg" controls />
              </div>
            )}
          </div>
        )}

        {uploadType === 'file' && (
          <>
            <div>
              <label className="mb-2 block text-sm font-medium text-neutral-300">Video File</label>
              {videoPreview ? (
                <div className="relative aspect-video overflow-hidden rounded-xl bg-black">
                  <video src={videoPreview} className="h-full w-full" controls />
                  <button type="button" onClick={() => { setVideoFile(null); setVideoPreview(null); setAutoThumbUrl(null); }} className="absolute right-2 top-2 rounded-full bg-black/70 p-1.5 text-white transition hover:bg-black"><X size={16} /></button>
                </div>
              ) : (
                <div onClick={() => fileInputRef.current?.click()} className="flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-neutral-700 bg-neutral-900 py-12 transition hover:border-neutral-500 hover:bg-neutral-800">
                  <Upload size={36} className="text-neutral-500" />
                  <p className="mt-3 text-sm text-neutral-300">Click to select a video file</p>
                  <p className="mt-1 text-xs text-neutral-500">MP4, WebM, MOV — up to 100MB</p>
                </div>
              )}
              <input ref={fileInputRef} type="file" accept="video/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleVideoFile(f); }} />
            </div>

            {/* Thumbnail */}
            <div>
              <label className="mb-2 block text-sm font-medium text-neutral-300">Thumbnail</label>
              {thumbPreview ? (
                <div className="relative w-64 overflow-hidden rounded-lg">
                  <img src={thumbPreview} alt="thumbnail" className="aspect-video w-full object-cover" />
                  <button type="button" onClick={() => { setThumbFile(null); setThumbPreview(null); }} className="absolute right-2 top-2 rounded-full bg-black/70 p-1.5 text-white transition hover:bg-black"><X size={16} /></button>
                </div>
              ) : autoThumbUrl ? (
                <div className="flex items-center gap-3">
                  <div className="relative w-64 overflow-hidden rounded-lg">
                    <img src={autoThumbUrl} alt="auto thumbnail" className="aspect-video w-full object-cover" />
                    <span className="absolute bottom-1 left-1 rounded bg-black/70 px-1.5 py-0.5 text-xs text-green-400">Auto-generated</span>
                  </div>
                  <button type="button" onClick={() => thumbInputRef.current?.click()} className="text-xs text-neutral-400 hover:text-white">Use custom instead</button>
                </div>
              ) : (
                <div onClick={() => thumbInputRef.current?.click()} className="flex w-64 cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-neutral-700 bg-neutral-900 py-6 transition hover:border-neutral-500">
                  <Image size={24} className="text-neutral-500" />
                  <p className="mt-2 text-xs text-neutral-400">Add custom thumbnail</p>
                  <p className="mt-0.5 text-xs text-neutral-600">Auto-generated if empty</p>
                </div>
              )}
              <input ref={thumbInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleThumbFile(f); }} />
            </div>
          </>
        )}

        {uploadType === 'youtube' && (
          <div>
            <label className="mb-2 block text-sm font-medium text-neutral-300">YouTube URL</label>
            <div className="relative">
              <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
              <input type="text" value={youtubeUrl} onChange={(e) => setYoutubeUrl(e.target.value)} placeholder="https://www.youtube.com/watch?v=..." className="w-full rounded-lg border border-neutral-700 bg-neutral-900 py-2.5 pl-10 pr-4 text-sm text-white outline-none transition focus:border-neutral-500" />
            </div>
            {youtubeUrl && extractYouTubeId(youtubeUrl) && (
              <div className="mt-3 overflow-hidden rounded-lg"><img src={getYouTubeThumbnail(extractYouTubeId(youtubeUrl)!)} alt="preview" className="aspect-video w-full max-w-xs object-cover" /></div>
            )}
          </div>
        )}

        {/* Rezzer toggle */}
        <div>
          <label className="mb-2 block text-sm font-medium text-neutral-300">Video Type</label>
          <div className="flex gap-2 rounded-lg bg-neutral-900 p-1">
            <button type="button" onClick={() => setIsShort(false)} className={`flex-1 rounded-md py-2 text-sm font-medium transition ${!isShort ? 'bg-neutral-700 text-white' : 'text-neutral-400 hover:text-neutral-200'}`}>Regular Video</button>
            <button type="button" onClick={() => setIsShort(true)} className={`flex-1 rounded-md py-2 text-sm font-medium transition ${isShort ? 'bg-neutral-700 text-white' : 'text-neutral-400 hover:text-neutral-200'}`}>Rezzer (Short)</button>
          </div>
          {isShort && (
            <div className="mt-3 space-y-3 rounded-lg border border-neutral-800 bg-neutral-900 p-3">
              {/* Apple Music search */}
              <div>
                <label className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-neutral-300"><Music size={14} /> Apple Music — Search for a song</label>
                <div className="relative">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
                  <input
                    type="text"
                    value={musicQuery}
                    onChange={(e) => {
                      setMusicQuery(e.target.value);
                      if (musicTimerRef.current) clearTimeout(musicTimerRef.current);
                      if (!e.target.value.trim()) { setMusicResults([]); return; }
                      setMusicSearching(true);
                      musicTimerRef.current = setTimeout(async () => {
                        try {
                          const res = await fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(e.target.value)}&media=music&limit=8`);
                          const json = await res.json();
                          setMusicResults((json.results ?? []).map((t: any) => ({
                            trackName: t.trackName,
                            artistName: t.artistName,
                            artworkUrl: (t.artworkUrl100 ?? '').replace('100x100', '200x200'),
                            previewUrl: t.previewUrl ?? '',
                            trackId: t.trackId,
                          })) as AppleMusicTrack[]);
                        } catch { /* ignore */ }
                        setMusicSearching(false);
                      }, 500);
                    }}
                    placeholder="Search Apple Music..."
                    className="w-full rounded-lg border border-neutral-700 bg-neutral-950 py-2 pl-9 pr-3 text-sm text-white outline-none focus:border-neutral-500"
                  />
                  {musicSearching && <Loader2 size={14} className="absolute right-3 top-1/2 -translate-y-1/2 animate-spin text-neutral-500" />}
                </div>
                {selectedTrack && (
                  <div className="mt-2 flex items-center gap-2 rounded-lg border border-red-500/40 bg-red-500/10 p-2">
                    {selectedTrack.artworkUrl && <img src={selectedTrack.artworkUrl} alt="art" className="h-10 w-10 rounded" />}
                    <div className="flex-1 min-w-0">
                      <p className="truncate text-xs font-medium text-white">{selectedTrack.trackName}</p>
                      <p className="truncate text-xs text-neutral-400">{selectedTrack.artistName}</p>
                    </div>
                    <button type="button" onClick={() => { setSelectedTrack(null); setMusicTitle(null); }} className="text-neutral-400 hover:text-red-400"><X size={14} /></button>
                  </div>
                )}
                {!selectedTrack && musicResults.length > 0 && (
                  <div className="mt-2 max-h-48 space-y-1 overflow-y-auto">
                    {musicResults.map((track) => (
                      <button
                        key={track.trackId}
                        type="button"
                        onClick={() => { setSelectedTrack(track); setMusicTitle(`${track.trackName} — ${track.artistName}`); setMusicResults([]); setMusicQuery(''); }}
                        className="flex w-full items-center gap-2 rounded-lg p-2 text-left transition hover:bg-neutral-800"
                      >
                        {track.artworkUrl && <img src={track.artworkUrl} alt="art" className="h-9 w-9 flex-shrink-0 rounded" />}
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-xs font-medium text-neutral-200">{track.trackName}</p>
                          <p className="truncate text-xs text-neutral-500">{track.artistName}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {/* Clip duration */}
              <div>
                <label className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-neutral-300"><Clock size={14} /> Clip Duration</label>
                <div className="flex gap-2">
                  {CLIP_DURATIONS.map((d) => (
                    <button key={d} type="button" onClick={() => setClipDuration(d)} className={`flex-1 rounded-lg py-2 text-sm font-medium transition ${(clipDuration ?? 15) === d ? 'bg-red-500 text-white' : 'bg-neutral-800 text-neutral-400 hover:text-white'}`}>{d}s</button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Title */}
        <div>
          <label className="mb-2 block text-sm font-medium text-neutral-300">Title</label>
          <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Enter a title for your video" maxLength={100} className="w-full rounded-lg border border-neutral-700 bg-neutral-900 px-4 py-2.5 text-sm text-white outline-none transition focus:border-neutral-500" required />
        </div>

        {/* Description */}
        <div>
          <label className="mb-2 block text-sm font-medium text-neutral-300">Description</label>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Tell viewers about your video..." rows={4} maxLength={2000} className="w-full resize-none rounded-lg border border-neutral-700 bg-neutral-900 px-4 py-2.5 text-sm text-white outline-none transition focus:border-neutral-500" />
        </div>

        {error && <p className="rounded-lg bg-red-500/10 px-4 py-2 text-sm text-red-400">{error}</p>}
        {uploading && <div className="flex items-center gap-3 text-sm text-neutral-300"><Loader2 size={18} className="animate-spin" /><span>Uploading... {progress}%</span></div>}

        <button type="submit" disabled={uploading} className="w-full rounded-lg bg-gradient-to-r from-red-500 to-orange-500 py-3 text-sm font-semibold text-white transition hover:from-red-600 hover:to-orange-600 disabled:opacity-50">
          {uploading ? 'Uploading...' : isShort ? 'Publish Rezzer' : 'Publish Video'}
        </button>
      </form>
    </div>
  );
}
