import { useState, useRef, useCallback } from 'react';
import { Camera, Loader2, Save, Check } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

interface CustomizePageProps {
  onNavigate: (path: string) => void;
}

export function CustomizePage({ onNavigate }: CustomizePageProps) {
  const { user, profile, refreshProfile } = useAuth();
  const [displayName, setDisplayName] = useState(profile?.display_name ?? '');
  const [username, setUsername] = useState(profile?.username ?? '');
  const [bio, setBio] = useState(profile?.bio ?? '');
  const [avatarUrl, setAvatarUrl] = useState(profile?.avatar_url ?? null);
  const [bannerUrl, setBannerUrl] = useState(profile?.banner_url ?? null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [uploadingBanner, setUploadingBanner] = useState(false);
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const bannerInputRef = useRef<HTMLInputElement>(null);

  const handleAvatarUpload = async (file: File) => {
    if (!user) return;
    setUploadingAvatar(true);
    setError(null);
    try {
      if (file.size > 5 * 1024 * 1024) {
        setError('Avatar must be under 5MB');
        setUploadingAvatar(false);
        return;
      }
      const ext = file.name.split('.').pop();
      const path = `${user.id}/avatar_${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from('avatars').upload(path, file, {
        cacheControl: '3600',
        upsert: true,
      });
      if (upErr) throw new Error(upErr.message);
      const url = supabase.storage.from('avatars').getPublicUrl(path).data.publicUrl;
      setAvatarUrl(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleBannerUpload = async (file: File) => {
    if (!user) return;
    setUploadingBanner(true);
    setError(null);
    try {
      if (file.size > 5 * 1024 * 1024) {
        setError('Banner must be under 5MB');
        setUploadingBanner(false);
        return;
      }
      const ext = file.name.split('.').pop();
      const path = `${user.id}/banner_${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from('avatars').upload(path, file, {
        cacheControl: '3600',
        upsert: true,
      });
      if (upErr) throw new Error(upErr.message);
      const url = supabase.storage.from('avatars').getPublicUrl(path).data.publicUrl;
      setBannerUrl(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploadingBanner(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    setError(null);
    setSaved(false);

    if (username.length < 3) {
      setError('Username must be at least 3 characters');
      setSaving(false);
      return;
    }
    if (!displayName.trim()) {
      setError('Display name is required');
      setSaving(false);
      return;
    }

    try {
      const { error: updErr } = await supabase
        .from('profiles')
        .update({
          display_name: displayName.trim(),
          username: username.trim(),
          bio: bio.trim() || null,
          avatar_url: avatarUrl,
          banner_url: bannerUrl,
        })
        .eq('id', user.id);

      if (updErr) {
        if (updErr.code === '23505') {
          setError('That username is already taken');
        } else {
          setError(updErr.message);
        }
        setSaving(false);
        return;
      }

      await refreshProfile();
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <p className="text-lg font-medium text-neutral-300">Sign in to customize your channel</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-6 sm:px-6">
      <h1 className="mb-6 text-2xl font-bold text-white">Customize Channel</h1>

      {/* Preview */}
      <div className="mb-6 overflow-hidden rounded-xl border border-neutral-800">
        <div
          className="h-32 sm:h-40 bg-cover bg-center bg-gradient-to-r from-red-600/30 via-orange-500/20 to-neutral-800"
          style={bannerUrl ? { backgroundImage: `url(${bannerUrl})` } : undefined}
        />
        <div className="bg-neutral-900 px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 overflow-hidden rounded-full bg-gradient-to-br from-red-500 to-orange-500">
              {avatarUrl ? (
                <img src={avatarUrl} alt="avatar" className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-lg font-bold text-white">
                  {(displayName[0] ?? 'U').toUpperCase()}
                </div>
              )}
            </div>
            <div>
              <p className="text-sm font-bold text-white">{displayName || 'Your Name'}</p>
              <p className="text-xs text-neutral-400">@{username || 'username'}</p>
            </div>
          </div>
          {bio && <p className="mt-2 text-sm text-neutral-300">{bio}</p>}
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-5">
        {/* Banner upload */}
        <div>
          <label className="mb-2 block text-sm font-medium text-neutral-300">Banner Image</label>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => bannerInputRef.current?.click()}
              disabled={uploadingBanner}
              className="flex items-center gap-2 rounded-lg border border-neutral-700 bg-neutral-900 px-4 py-2.5 text-sm text-neutral-200 transition hover:bg-neutral-800 disabled:opacity-50"
            >
              {uploadingBanner ? <Loader2 size={16} className="animate-spin" /> : <Camera size={16} />}
              {bannerUrl ? 'Change Banner' : 'Upload Banner'}
            </button>
            {bannerUrl && (
              <button
                type="button"
                onClick={() => setBannerUrl(null)}
                className="text-sm text-neutral-400 transition hover:text-red-400"
              >
                Remove
              </button>
            )}
          </div>
          <input
            ref={bannerInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleBannerUpload(file);
            }}
          />
        </div>

        {/* Avatar upload */}
        <div>
          <label className="mb-2 block text-sm font-medium text-neutral-300">Avatar</label>
          <div className="flex items-center gap-3">
            <div className="h-16 w-16 overflow-hidden rounded-full bg-gradient-to-br from-red-500 to-orange-500">
              {avatarUrl ? (
                <img src={avatarUrl} alt="avatar" className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-xl font-bold text-white">
                  {(displayName[0] ?? 'U').toUpperCase()}
                </div>
              )}
            </div>
            <button
              type="button"
              onClick={() => avatarInputRef.current?.click()}
              disabled={uploadingAvatar}
              className="flex items-center gap-2 rounded-lg border border-neutral-700 bg-neutral-900 px-4 py-2.5 text-sm text-neutral-200 transition hover:bg-neutral-800 disabled:opacity-50"
            >
              {uploadingAvatar ? <Loader2 size={16} className="animate-spin" /> : <Camera size={16} />}
              {avatarUrl ? 'Change Avatar' : 'Upload Avatar'}
            </button>
            {avatarUrl && (
              <button
                type="button"
                onClick={() => setAvatarUrl(null)}
                className="text-sm text-neutral-400 transition hover:text-red-400"
              >
                Remove
              </button>
            )}
          </div>
          <input
            ref={avatarInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleAvatarUpload(file);
            }}
          />
        </div>

        {/* Display name */}
        <div>
          <label className="mb-2 block text-sm font-medium text-neutral-300">Display Name</label>
          <input
            type="text"
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            maxLength={50}
            className="w-full rounded-lg border border-neutral-700 bg-neutral-900 px-4 py-2.5 text-sm text-white outline-none transition focus:border-neutral-500"
            required
          />
        </div>

        {/* Username */}
        <div>
          <label className="mb-2 block text-sm font-medium text-neutral-300">Username</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500">@</span>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value.replace(/[^a-zA-Z0-9_]/g, '').toLowerCase())}
              maxLength={30}
              className="w-full rounded-lg border border-neutral-700 bg-neutral-900 py-2.5 pl-8 pr-4 text-sm text-white outline-none transition focus:border-neutral-500"
              required
            />
          </div>
          <p className="mt-1 text-xs text-neutral-500">Letters, numbers, and underscores only.</p>
        </div>

        {/* Bio */}
        <div>
          <label className="mb-2 block text-sm font-medium text-neutral-300">Channel Bio</label>
          <textarea
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            rows={3}
            maxLength={200}
            placeholder="Tell viewers about your channel..."
            className="w-full resize-none rounded-lg border border-neutral-700 bg-neutral-900 px-4 py-2.5 text-sm text-white outline-none transition focus:border-neutral-500"
          />
          <p className="mt-1 text-right text-xs text-neutral-500">{bio.length}/200</p>
        </div>

        {error && (
          <p className="rounded-lg bg-red-500/10 px-4 py-2 text-sm text-red-400">{error}</p>
        )}

        <div className="flex items-center gap-3">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-red-500 to-orange-500 px-6 py-2.5 text-sm font-semibold text-white transition hover:from-red-600 hover:to-orange-600 disabled:opacity-50"
          >
            {saving ? <Loader2 size={16} className="animate-spin" /> : saved ? <Check size={16} /> : <Save size={16} />}
            {saving ? 'Saving...' : saved ? 'Saved!' : 'Save Changes'}
          </button>
          <button
            type="button"
            onClick={() => onNavigate(`/channel/${user.id}`)}
            className="rounded-lg border border-neutral-700 px-4 py-2.5 text-sm text-neutral-300 transition hover:bg-neutral-800"
          >
            View Channel
          </button>
        </div>
      </form>
    </div>
  );
}
