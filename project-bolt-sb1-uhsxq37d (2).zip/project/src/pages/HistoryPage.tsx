import { useState, useEffect, useCallback } from 'react';
import { Clock, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { VideoWithDetails } from '@/types';
import { VideoCard } from '@/components/VideoCard';
import { timeAgo } from '@/lib/utils';

interface HistoryPageProps {
  onNavigate: (path: string) => void;
  onOpenAuth: () => void;
}

export function HistoryPage({ onNavigate, onOpenAuth }: HistoryPageProps) {
  const { user } = useAuth();
  const [videos, setVideos] = useState<VideoWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchHistory = useCallback(async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('watch_history')
      .select(`
        watched_at,
        videos:video_id (
          *,
          profiles:user_id (id, username, display_name, avatar_url)
        )
      `)
      .eq('user_id', user.id)
      .order('watched_at', { ascending: false })
      .limit(100);

    if (error || !data) {
      setVideos([]);
      setLoading(false);
      return;
    }

    const vids = data
      .map((row) => (row as unknown as { videos: VideoWithDetails }).videos)
      .filter(Boolean) as VideoWithDetails[];
    setVideos(vids);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  const clearHistory = async () => {
    if (!user) return;
    if (!confirm('Clear all watch history? This cannot be undone.')) return;
    await supabase.from('watch_history').delete().eq('user_id', user.id);
    setVideos([]);
  };

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <Clock size={48} className="text-neutral-600" />
        <p className="mt-4 text-lg font-medium text-neutral-300">Sign in to see your history</p>
        <p className="mt-1 text-sm text-neutral-500">Your watch history appears here once you sign in.</p>
        <button
          onClick={onOpenAuth}
          className="mt-4 rounded-lg bg-gradient-to-r from-red-500 to-orange-500 px-5 py-2 text-sm font-semibold text-white transition hover:from-red-600 hover:to-orange-600"
        >
          Sign In
        </button>
      </div>
    );
  }

  return (
    <div className="px-4 py-6 sm:px-6">
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Clock size={24} className="text-neutral-300" />
          <h1 className="text-2xl font-bold text-white">Watch History</h1>
        </div>
        {videos.length > 0 && (
          <button
            onClick={clearHistory}
            className="flex items-center gap-2 rounded-full bg-neutral-800 px-4 py-2 text-sm font-medium text-neutral-300 transition hover:bg-neutral-700 hover:text-red-400"
          >
            <Trash2 size={16} /> Clear History
          </button>
        )}
      </div>

      {loading ? (
        <div className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="aspect-video rounded-xl bg-neutral-800" />
              <div className="mt-2 flex gap-3">
                <div className="h-9 w-9 rounded-full bg-neutral-800" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 w-3/4 rounded bg-neutral-800" />
                  <div className="h-3 w-1/2 rounded bg-neutral-800" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : videos.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Clock size={48} className="text-neutral-600" />
          <p className="mt-4 text-lg font-medium text-neutral-300">No watch history yet</p>
          <p className="mt-1 text-sm text-neutral-500">Videos you watch will show up here.</p>
          <button
            onClick={() => onNavigate('/')}
            className="mt-4 rounded-lg bg-neutral-800 px-5 py-2 text-sm font-semibold text-white transition hover:bg-neutral-700"
          >
            Browse Videos
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {videos.map((video) => (
            <VideoCard key={video.id} video={video} onNavigate={onNavigate} />
          ))}
        </div>
      )}
    </div>
  );
}
