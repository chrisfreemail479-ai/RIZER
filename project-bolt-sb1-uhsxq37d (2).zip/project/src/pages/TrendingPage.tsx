import { useState, useEffect, useCallback } from 'react';
import { Flame } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { VideoWithDetails } from '@/types';
import { VideoCard } from '@/components/VideoCard';

interface TrendingPageProps {
  onNavigate: (path: string) => void;
}

export function TrendingPage({ onNavigate }: TrendingPageProps) {
  const [videos, setVideos] = useState<VideoWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchTrending = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('videos')
      .select(`
        *,
        profiles:user_id (id, username, display_name, avatar_url)
      `)
      .order('views', { ascending: false })
      .limit(48);

    if (error || !data) {
      setVideos([]);
      setLoading(false);
      return;
    }

    const vids = (data ?? []) as unknown as VideoWithDetails[];
    if (vids.length > 0) {
      const videoIds = vids.map((v) => v.id);
      const [{ data: likesData }] = await Promise.all([
        supabase.from('likes').select('video_id').in('video_id', videoIds),
      ]);
      const likeCounts: Record<string, number> = {};
      (likesData ?? []).forEach((l) => {
        likeCounts[l.video_id] = (likeCounts[l.video_id] ?? 0) + 1;
      });
      vids.forEach((v) => {
        v.like_count = likeCounts[v.id] ?? 0;
      });
      vids.sort((a, b) => {
        const aScore = (a.views ?? 0) + (a.like_count ?? 0) * 2;
        const bScore = (b.views ?? 0) + (b.like_count ?? 0) * 2;
        return bScore - aScore;
      });
    }
    setVideos(vids);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchTrending();
  }, [fetchTrending]);

  return (
    <div className="px-4 py-6 sm:px-6">
      <div className="mb-6 flex items-center gap-3">
        <Flame size={24} className="text-orange-500" />
        <div>
          <h1 className="text-2xl font-bold text-white">Trending</h1>
          <p className="mt-0.5 text-sm text-neutral-400">The most popular videos on RIZER right now</p>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="aspect-video rounded-xl bg-neutral-800" />
              <div className="mt-2 flex gap-3">
                <div className="h-9 w-9 rounded-full bg-neutral-800" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 w-3/4 rounded bg-neutral-800" />
                  <div className="h-3 w-1/2 rounded bg-neutral-800" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : videos.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Flame size={48} className="text-neutral-600" />
          <p className="mt-4 text-lg font-medium text-neutral-300">No trending videos yet</p>
          <p className="mt-1 text-sm text-neutral-500">Once people start watching and liking, trending videos will appear here.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {videos.map((video, i) => (
            <div key={video.id} className="relative">
              {i < 3 && (
                <div className="absolute -left-1 -top-1 z-10 flex h-7 items-center gap-1 rounded-full bg-gradient-to-r from-red-500 to-orange-500 px-2.5 text-xs font-bold text-white shadow-lg">
                  <Flame size={12} /> #{i + 1}
                </div>
              )}
              <VideoCard video={video} onNavigate={onNavigate} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
