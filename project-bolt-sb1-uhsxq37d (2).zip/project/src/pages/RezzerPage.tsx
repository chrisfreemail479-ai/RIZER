import { useState, useEffect, useCallback, useRef } from 'react';
import { ThumbsUp, ThumbsDown, MessageCircle, Share2, ChevronUp, ChevronDown, X, Send, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { VideoWithDetails, Comment } from '@/types';
import { formatCount, timeAgo, getYouTubeEmbedUrl } from '@/lib/utils';
import { SubscribeButton } from '@/components/SubscribeButton';

interface RezzerPageProps {
  onNavigate: (path: string) => void;
  onOpenAuth: () => void;
}

interface CommentWithMeta extends Comment {
  like_count: number;
  liked_by_me: boolean;
  replies: CommentWithMeta[];
}

export function RezzerPage({ onNavigate, onOpenAuth }: RezzerPageProps) {
  const { user, profile } = useAuth();
  const [videos, setVideos] = useState<VideoWithDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [likeCounts, setLikeCounts] = useState<Record<string, number>>({});
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({});
  const [commentCounts, setCommentCounts] = useState<Record<string, number>>({});
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [comments, setComments] = useState<CommentWithMeta[]>([]);
  const [newComment, setNewComment] = useState('');
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [commentsLoading, setCommentsLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const fetchRezzers = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('videos')
      .select(`
        *,
        profiles:user_id (id, username, display_name, avatar_url)
      `)
      .eq('is_short', true)
      .order('created_at', { ascending: false })
      .limit(50);

    if (error || !data) {
      setVideos([]);
      setLoading(false);
      return;
    }

    const vids = (data ?? []) as unknown as VideoWithDetails[];
    if (vids.length > 0) {
      const videoIds = vids.map((v) => v.id);
      const [{ data: likesData }, { data: commentsData }] = await Promise.all([
        supabase.from('likes').select('video_id, user_id').in('video_id', videoIds),
        supabase.from('comments').select('video_id').in('video_id', videoIds),
      ]);
      const lc: Record<string, number> = {};
      const lm: Record<string, boolean> = {};
      const cc: Record<string, number> = {};
      (likesData ?? []).forEach((l) => {
        lc[l.video_id] = (lc[l.video_id] ?? 0) + 1;
        if (user && l.user_id === user.id) lm[l.video_id] = true;
      });
      (commentsData ?? []).forEach((c) => {
        cc[c.video_id] = (cc[c.video_id] ?? 0) + 1;
      });
      setLikeCounts(lc);
      setLikedMap(lm);
      setCommentCounts(cc);
    }
    setVideos(vids);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchRezzers();
  }, [fetchRezzers]);

  const current = videos[currentIndex];

  const fetchComments = useCallback(async (videoId: string) => {
    setCommentsLoading(true);
    const { data } = await supabase
      .from('comments')
      .select(`*, profiles:user_id (id, username, display_name, avatar_url)`)
      .eq('video_id', videoId)
      .order('created_at', { ascending: false });

    const allComments = (data ?? []) as unknown as Comment[];
    const commentIds = allComments.map((c) => c.id);

    let likeMap: Record<string, number> = {};
    let myLikes: Record<string, boolean> = {};
    if (commentIds.length > 0) {
      const { data: clData } = await supabase.from('comment_likes').select('comment_id, user_id').in('comment_id', commentIds);
      (clData ?? []).forEach((cl) => {
        likeMap[cl.comment_id] = (likeMap[cl.comment_id] ?? 0) + 1;
        if (user && cl.user_id === user.id) myLikes[cl.comment_id] = true;
      });
    }

    const withMeta: CommentWithMeta[] = allComments.map((c) => ({
      ...c,
      like_count: likeMap[c.id] ?? 0,
      liked_by_me: !!myLikes[c.id],
      replies: [],
    }));

    const topLevel = withMeta.filter((c) => !c.parent_id);
    const replyMap: Record<string, CommentWithMeta[]> = {};
    withMeta.filter((c) => c.parent_id).forEach((r) => {
      if (!replyMap[r.parent_id!]) replyMap[r.parent_id!] = [];
      replyMap[r.parent_id!].push(r);
    });
    topLevel.forEach((c) => { c.replies = replyMap[c.id] ?? []; });

    setComments(topLevel);
    setCommentsLoading(false);
  }, [user]);

  const handleLike = async (videoId: string) => {
    if (!user) { onOpenAuth(); return; }
    if (likedMap[videoId]) {
      await supabase.from('likes').delete().eq('video_id', videoId).eq('user_id', user.id);
      setLikedMap((p) => ({ ...p, [videoId]: false }));
      setLikeCounts((p) => ({ ...p, [videoId]: (p[videoId] ?? 1) - 1 }));
    } else {
      await supabase.from('likes').insert({ video_id: videoId, user_id: user.id });
      setLikedMap((p) => ({ ...p, [videoId]: true }));
      setLikeCounts((p) => ({ ...p, [videoId]: (p[videoId] ?? 0) + 1 }));
    }
  };

  const openComments = () => {
    if (!current) return;
    setCommentsOpen(true);
    fetchComments(current.id);
  };

  const closeComments = () => {
    setCommentsOpen(false);
    setComments([]);
    setNewComment('');
    setReplyingTo(null);
    setReplyText('');
  };

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newComment.trim() || !current) return;
    const { data } = await supabase
      .from('comments')
      .insert({ video_id: current.id, user_id: user.id, content: newComment.trim() })
      .select(`*, profiles:user_id (id, username, display_name, avatar_url)`)
      .single();
    if (data) {
      const c = data as unknown as Comment;
      setComments((prev) => [{ ...c, like_count: 0, liked_by_me: false, replies: [] }, ...prev]);
      setNewComment('');
      setCommentCounts((p) => ({ ...p, [current.id]: (p[current.id] ?? 0) + 1 }));
    }
  };

  const handleReply = async (parentId: string) => {
    if (!user || !replyText.trim() || !current) return;
    const { data } = await supabase
      .from('comments')
      .insert({ video_id: current.id, user_id: user.id, content: replyText.trim(), parent_id: parentId })
      .select(`*, profiles:user_id (id, username, display_name, avatar_url)`)
      .single();
    if (data) {
      const r = data as unknown as Comment;
      setComments((prev) =>
        prev.map((c) =>
          c.id === parentId
            ? { ...c, replies: [...c.replies, { ...r, like_count: 0, liked_by_me: false, replies: [] }] }
            : c
        )
      );
      setReplyText('');
      setReplyingTo(null);
      setCommentCounts((p) => ({ ...p, [current.id]: (p[current.id] ?? 0) + 1 }));
    }
  };

  const handleCommentLike = async (commentId: string, isLiked: boolean) => {
    if (!user) { onOpenAuth(); return; }
    if (isLiked) {
      await supabase.from('comment_likes').delete().eq('comment_id', commentId).eq('user_id', user.id);
    } else {
      await supabase.from('comment_likes').insert({ comment_id: commentId, user_id: user.id });
    }
    setComments((prev) =>
      prev.map((c) => {
        if (c.id === commentId) {
          return { ...c, liked_by_me: !isLiked, like_count: c.like_count + (isLiked ? -1 : 1) };
        }
        return {
          ...c,
          replies: c.replies.map((r) =>
            r.id === commentId
              ? { ...r, liked_by_me: !isLiked, like_count: r.like_count + (isLiked ? -1 : 1) }
              : r
          ),
        };
      })
    );
  };

  const handleDeleteComment = async (commentId: string) => {
    await supabase.from('comments').delete().eq('id', commentId).eq('user_id', user!.id);
    setComments((prev) => prev.filter((c) => c.id !== commentId && c.parent_id !== commentId));
    if (current) setCommentCounts((p) => ({ ...p, [current.id]: Math.max(0, (p[current.id] ?? 1) - 1) }));
  };

  const scrollNext = () => {
    if (currentIndex < videos.length - 1) { setCurrentIndex((i) => i + 1); closeComments(); }
  };
  const scrollPrev = () => {
    if (currentIndex > 0) { setCurrentIndex((i) => i - 1); closeComments(); }
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); scrollNext(); }
      if (e.key === 'ArrowUp') { e.preventDefault(); scrollPrev(); }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  });

  const renderAvatar = (avatarUrl?: string | null, name?: string, size = 'h-8 w-8') => (
    <div className={`${size} flex-shrink-0 overflow-hidden rounded-full bg-gradient-to-br from-red-500 to-orange-500`}>
      {avatarUrl ? (
        <img src={avatarUrl} alt="avatar" className="h-full w-full object-cover" />
      ) : (
        <div className="flex h-full w-full items-center justify-center text-xs font-bold text-white">{(name?.[0] ?? 'U').toUpperCase()}</div>
      )}
    </div>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-neutral-700 border-t-red-500" />
      </div>
    );
  }

  if (videos.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <p className="text-lg font-medium text-neutral-300">No Rezzers yet</p>
        <p className="mt-1 text-sm text-neutral-500">Upload a short vertical video and mark it as a Rezzer!</p>
        <button onClick={() => onNavigate('/upload')} className="mt-4 rounded-lg bg-gradient-to-r from-red-500 to-orange-500 px-5 py-2 text-sm font-semibold text-white transition hover:from-red-600 hover:to-orange-600">
          Upload Rezzer
        </button>
      </div>
    );
  }

  return (
    <div ref={containerRef} className="relative flex h-full items-center justify-center bg-black overflow-hidden">
      {/* Navigation arrows */}
      {currentIndex > 0 && (
        <button onClick={scrollPrev} className="absolute left-4 top-1/2 z-20 -translate-y-1/2 rounded-full bg-neutral-800/80 p-2 text-white transition hover:bg-neutral-700">
          <ChevronUp size={24} />
        </button>
      )}
      {currentIndex < videos.length - 1 && (
        <button onClick={scrollNext} className="absolute left-4 top-1/2 z-20 translate-y-8 rounded-full bg-neutral-800/80 p-2 text-white transition hover:bg-neutral-700">
          <ChevronDown size={24} />
        </button>
      )}

      {/* Video + comment panel layout */}
      <div className="relative flex h-full w-full max-w-[800px] items-center justify-center">
        {/* Video container */}
        <div className={`relative h-full transition-all duration-300 ${commentsOpen ? 'w-full sm:w-[55%]' : 'w-full max-w-[450px]'}`}>
          <div className="relative h-full w-full bg-black">
            {current.video_type === 'youtube' && current.youtube_id ? (
              <iframe src={getYouTubeEmbedUrl(current.youtube_id)} className="h-full w-full" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen title={current.title} />
            ) : current.video_url ? (
              <video src={current.video_url} className="h-full w-full" controls autoPlay poster={current.thumbnail_url ?? undefined} />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-neutral-500">Video unavailable</div>
            )}
          </div>

          {/* Overlay info (hidden when comments open on mobile) */}
          {!commentsOpen && (
            <>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                <div className="flex items-center gap-2">
                  <button onClick={() => onNavigate(`/channel/${current.user_id}`)} className="h-9 w-9 overflow-hidden rounded-full bg-gradient-to-br from-red-500 to-orange-500">
                    {current.profiles?.avatar_url ? (
                      <img src={current.profiles.avatar_url} alt="avatar" className="h-full w-full object-cover" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-sm font-bold text-white">{(current.profiles?.display_name?.[0] ?? 'U').toUpperCase()}</div>
                    )}
                  </button>
                  <button onClick={() => onNavigate(`/channel/${current.user_id}`)} className="text-sm font-medium text-white hover:text-neutral-200">{current.profiles?.display_name}</button>
                  {current.user_id !== user?.id && <SubscribeButton channelId={current.user_id} onOpenAuth={onOpenAuth} />}
                </div>
                <p className="mt-2 line-clamp-2 text-sm text-white">{current.title}</p>
                <p className="mt-0.5 text-xs text-neutral-400">{formatCount(current.views)} views • {timeAgo(current.created_at)}</p>
              </div>

              {/* Right action bar */}
              <div className="absolute bottom-20 right-2 flex flex-col items-center gap-4">
                <button onClick={() => handleLike(current.id)} className="flex flex-col items-center gap-1">
                  <div className={`flex h-11 w-11 items-center justify-center rounded-full transition ${likedMap[current.id] ? 'bg-red-500/20 text-red-400' : 'bg-neutral-800/80 text-white hover:bg-neutral-700'}`}>
                    <ThumbsUp size={20} className={likedMap[current.id] ? 'fill-red-400' : ''} />
                  </div>
                  <span className="text-xs text-white">{formatCount(likeCounts[current.id] ?? 0)}</span>
                </button>
                <button className="flex flex-col items-center gap-1">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-neutral-800/80 text-white transition hover:bg-neutral-700"><ThumbsDown size={20} /></div>
                </button>
                <button onClick={openComments} className="flex flex-col items-center gap-1">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-neutral-800/80 text-white transition hover:bg-neutral-700"><MessageCircle size={20} /></div>
                  <span className="text-xs text-white">{formatCount(commentCounts[current.id] ?? 0)}</span>
                </button>
                <button className="flex flex-col items-center gap-1">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-neutral-800/80 text-white transition hover:bg-neutral-700"><Share2 size={20} /></div>
                </button>
              </div>
            </>
          )}
        </div>

        {/* Comment panel — slides in from the right */}
        {commentsOpen && (
          <div className="absolute right-0 top-0 z-30 flex h-full w-full flex-col bg-neutral-950 sm:w-[45%] sm:border-l sm:border-neutral-800">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-neutral-800 px-4 py-3">
              <h3 className="text-sm font-bold text-white">{commentCounts[current.id] ?? 0} Comments</h3>
              <button onClick={closeComments} className="text-neutral-400 transition hover:text-white"><X size={20} /></button>
            </div>

            {/* Comment input */}
            {user ? (
              <form onSubmit={handleComment} className="flex gap-2 border-b border-neutral-800 px-4 py-3">
                {renderAvatar(profile?.avatar_url, profile?.display_name, 'h-8 w-8')}
                <div className="flex-1">
                  <input
                    type="text"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Add a comment..."
                    className="w-full border-b border-neutral-700 bg-transparent pb-1 text-sm text-white outline-none focus:border-neutral-500"
                  />
                  {newComment && (
                    <div className="mt-1.5 flex justify-end gap-2">
                      <button type="button" onClick={() => setNewComment('')} className="rounded-full px-2 py-1 text-xs text-neutral-400 hover:bg-neutral-800">Cancel</button>
                      <button type="submit" className="flex items-center gap-1 rounded-full bg-red-500 px-2.5 py-1 text-xs font-medium text-white hover:bg-red-600"><Send size={12} /> Comment</button>
                    </div>
                  )}
                </div>
              </form>
            ) : (
              <div className="border-b border-neutral-800 px-4 py-3 text-center">
                <p className="text-xs text-neutral-400">You need to <button onClick={onOpenAuth} className="font-medium text-red-400 hover:text-red-300">sign in</button> to comment.</p>
              </div>
            )}

            {/* Comments list */}
            <div className="flex-1 overflow-y-auto px-4 py-3">
              {commentsLoading ? (
                <div className="flex justify-center py-8"><div className="h-6 w-6 animate-spin rounded-full border-2 border-neutral-700 border-t-red-500" /></div>
              ) : comments.length === 0 ? (
                <p className="py-8 text-center text-sm text-neutral-500">No comments yet. Be the first!</p>
              ) : (
                <div className="space-y-4">
                  {comments.map((comment) => (
                    <div key={comment.id}>
                      <div className="flex gap-2">
                        <button onClick={() => onNavigate(`/channel/${comment.user_id}`)}>{renderAvatar(comment.profiles?.avatar_url, comment.profiles?.display_name, 'h-8 w-8')}</button>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-medium text-white">{comment.profiles?.display_name}</span>
                            <span className="text-xs text-neutral-500">{timeAgo(comment.created_at)}</span>
                          </div>
                          <p className="mt-0.5 text-sm text-neutral-300">{comment.content}</p>
                          <div className="mt-1 flex items-center gap-3">
                            <button onClick={() => handleCommentLike(comment.id, comment.liked_by_me)} className={`flex items-center gap-1 text-xs transition ${comment.liked_by_me ? 'text-red-400' : 'text-neutral-400 hover:text-neutral-200'}`}>
                              <ThumbsUp size={11} className={comment.liked_by_me ? 'fill-red-400' : ''} /> {comment.like_count > 0 && formatCount(comment.like_count)}
                            </button>
                            {user && <button onClick={() => setReplyingTo(replyingTo === comment.id ? null : comment.id)} className="text-xs text-neutral-400 hover:text-neutral-200">Reply</button>}
                            {comment.user_id === user?.id && <button onClick={() => handleDeleteComment(comment.id)} className="text-neutral-500 transition hover:text-red-400"><Trash2 size={11} /></button>}
                          </div>

                          {/* Reply input */}
                          {replyingTo === comment.id && user && (
                            <div className="mt-2 flex gap-2">
                              {renderAvatar(profile?.avatar_url, profile?.display_name, 'h-6 w-6')}
                              <div className="flex-1">
                                <input type="text" value={replyText} onChange={(e) => setReplyText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') handleReply(comment.id); }} placeholder="Add a reply..." className="w-full border-b border-neutral-700 bg-transparent pb-0.5 text-sm text-white outline-none focus:border-neutral-500" />
                                <div className="mt-1 flex justify-end gap-2">
                                  <button onClick={() => { setReplyingTo(null); setReplyText(''); }} className="rounded-full px-2 py-0.5 text-xs text-neutral-400 hover:bg-neutral-800">Cancel</button>
                                  <button onClick={() => handleReply(comment.id)} className="rounded-full bg-red-500 px-2 py-0.5 text-xs font-medium text-white hover:bg-red-600">Reply</button>
                                </div>
                              </div>
                            </div>
                          )}

                          {/* Replies */}
                          {comment.replies.length > 0 && (
                            <div className="mt-2 space-y-2 border-l border-neutral-800 pl-3">
                              {comment.replies.map((reply) => (
                                <div key={reply.id} className="flex gap-2">
                                  <button onClick={() => onNavigate(`/channel/${reply.user_id}`)}>{renderAvatar(reply.profiles?.avatar_url, reply.profiles?.display_name, 'h-6 w-6')}</button>
                                  <div className="flex-1">
                                    <div className="flex items-center gap-2">
                                      <span className="text-xs font-medium text-white">{reply.profiles?.display_name}</span>
                                      <span className="text-xs text-neutral-500">{timeAgo(reply.created_at)}</span>
                                    </div>
                                    <p className="mt-0.5 text-sm text-neutral-300">{reply.content}</p>
                                    <div className="mt-1 flex items-center gap-3">
                                      <button onClick={() => handleCommentLike(reply.id, reply.liked_by_me)} className={`flex items-center gap-1 text-xs transition ${reply.liked_by_me ? 'text-red-400' : 'text-neutral-400 hover:text-neutral-200'}`}>
                                        <ThumbsUp size={11} className={reply.liked_by_me ? 'fill-red-400' : ''} /> {reply.like_count > 0 && formatCount(reply.like_count)}
                                      </button>
                                      {reply.user_id === user?.id && <button onClick={() => handleDeleteComment(reply.id)} className="text-neutral-500 transition hover:text-red-400"><Trash2 size={11} /></button>}
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Progress indicator */}
      <div className="absolute right-1 top-1/2 z-20 -translate-y-1/2 flex flex-col gap-1">
        {videos.slice(0, 10).map((_, i) => (
          <div key={i} className={`w-1 rounded-full transition-all ${i === currentIndex ? 'h-6 bg-red-500' : 'h-2 bg-neutral-700'}`} />
        ))}
      </div>
    </div>
  );
}
