import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { Profile, VideoWithDetails } from '@/types';
import { VideoCard } from '@/components/VideoCard';
import { SubscribeButton } from '@/components/SubscribeButton';
import { PostComposer } from '@/components/PostComposer';
import { PostList } from '@/components/PostList';
import { formatViews, timeAgo, formatCount } from '@/lib/utils';

interface ChannelPageProps {
  userId: string;
  onNavigate: (path: string) => void;
  currentUserId: string | null;
  onOpenAuth: () => void;
}

type Tab = 'videos' | 'rezzers' | 'trending' | 'posts';

export function ChannelPage({ userId, onNavigate, currentUserId, onOpenAuth }: ChannelPageProps) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [allVideos, setAllVideos] = useState<VideoWithDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [subCount, setSubCount] = useState(0);
  const [tab, setTab] = useState<Tab>('videos');
  const [postRefresh, setPostRefresh] = useState(0);

  const fetchChannel = useCallback(async () => {
    setLoading(true);
    const [{ data: prof }, { data: vids }, { count: subs }] = await Promise.all([
      supabase.from('profiles').select('*').eq('id', userId).maybeSingle(),
      supabase.from('videos').select(`*, profiles:user_id (id, username, display_name, avatar_url)`).eq('user_id', userId).order('created_at', { ascending: false }),
      supabase.from('subscriptions').select('*', { count: 'exact', head: true }).eq('channel_id', userId),
    ]);
    setProfile(prof as Profile | null);
    setAllVideos((vids ?? []) as unknown as VideoWithDetails[]);
    setSubCount(subs ?? 0);
    setLoading(false);
  }, [userId]);

  useEffect(() => { fetchChannel(); }, [fetchChannel]);

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-neutral-700 border-t-red-500" /></div>;
  }

  if (!profile) {
    return <div className="flex flex-col items-center justify-center py-20 text-center"><p className="text-lg font-medium text-neutral-300">Channel not found</p></div>;
  }

  const isOwnChannel = currentUserId === userId;
  const totalViews = allVideos.reduce((sum, v) => sum + v.views, 0);
  const regularVideos = allVideos.filter((v) => !v.is_short);
  const rezzerVideos = allVideos.filter((v) => v.is_short);
  const trendingVideos = [...allVideos].sort((a, b) => b.views - a.views);

  const tabs: { key: Tab; label: string; count: number }[] = [
    { key: 'videos', label: 'Videos', count: regularVideos.length },
    { key: 'rezzers', label: 'Rezzers', count: rezzerVideos.length },
    { key: 'trending', label: 'Trending', count: trendingVideos.length },
    { key: 'posts', label: 'Posts', count: 0 },
  ];

  const tabVideos = tab === 'rezzers' ? rezzerVideos : tab === 'trending' ? trendingVideos : regularVideos;

  return (
    <div className="px-4 py-6 sm:px-6">
      {/* Banner */}
      <div className="h-32 rounded-xl bg-cover bg-center bg-gradient-to-r from-red-600/30 via-orange-500/20 to-neutral-800 sm:h-40" style={profile.banner_url ? { backgroundImage: `url(${profile.banner_url})` } : undefined} />

      {/* Profile info */}
      <div className="mt-4 flex flex-col items-start gap-4 sm:flex-row sm:items-center">
        <div className="h-20 w-20 overflow-hidden rounded-full bg-gradient-to-br from-red-500 to-orange-500 sm:h-24 sm:w-24">
          {profile.avatar_url ? <img src={profile.avatar_url} alt="avatar" className="h-full w-full object-cover" /> : <div className="flex h-full w-full items-center justify-center text-3xl font-bold text-white">{profile.display_name[0].toUpperCase()}</div>}
        </div>
        <div className="flex-1">
          <h1 className="text-xl font-bold text-white sm:text-2xl">{profile.display_name}</h1>
          <p className="text-sm text-neutral-400">@{profile.username}</p>
          {profile.bio && <p className="mt-2 max-w-2xl text-sm text-neutral-300">{profile.bio}</p>}
          <div className="mt-2 flex flex-wrap gap-4 text-sm text-neutral-400">
            <span><strong className="text-white">{formatCount(subCount)}</strong> subscribers</span>
            <span><strong className="text-white">{allVideos.length}</strong> videos</span>
            <span><strong className="text-white">{formatViews(totalViews)}</strong></span>
            <span>Joined {timeAgo(profile.created_at)}</span>
          </div>
        </div>
        {isOwnChannel ? (
          <div className="flex gap-2">
            <button onClick={() => onNavigate('/customize')} className="rounded-full bg-neutral-800 px-4 py-2 text-sm font-medium text-white transition hover:bg-neutral-700">Customize Channel</button>
            <button onClick={() => onNavigate('/upload')} className="rounded-full bg-neutral-800 px-4 py-2 text-sm font-medium text-white transition hover:bg-neutral-700">Upload Video</button>
          </div>
        ) : (
          <SubscribeButton channelId={userId} onOpenAuth={onOpenAuth} />
        )}
      </div>

      {/* Tabs */}
      <div className="mt-6 flex gap-1 border-b border-neutral-800">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`relative px-4 py-2.5 text-sm font-medium transition ${tab === t.key ? 'text-white' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            {t.label}
            {t.count > 0 && <span className="ml-1.5 text-xs text-neutral-500">{t.count}</span>}
            {tab === t.key && <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-red-500" />}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="mt-6">
        {tab === 'posts' ? (
          <div className="mx-auto max-w-2xl space-y-4">
            {isOwnChannel && <PostComposer userId={userId} onPosted={() => setPostRefresh((c) => c + 1)} />}
            <PostList key={postRefresh} userId={userId} onNavigate={onNavigate} />
          </div>
        ) : tabVideos.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <p className="text-sm text-neutral-500">{isOwnChannel ? `You haven't uploaded any ${tab} yet.` : `No ${tab} yet.`}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {tabVideos.map((video) => <VideoCard key={video.id} video={video} onNavigate={onNavigate} />)}
          </div>
        )}
      </div>
    </div>
  );
}
