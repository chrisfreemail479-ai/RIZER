import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { VideoWithDetails } from '@/types';
import { VideoCard } from '@/components/VideoCard';
import { Search } from 'lucide-react';

interface SearchPageProps {
  query: string;
  onNavigate: (path: string) => void;
}

export function SearchPage({ query, onNavigate }: SearchPageProps) {
  const [videos, setVideos] = useState<VideoWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchResults = useCallback(async () => {
    if (!query.trim()) {
      setVideos([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('videos')
      .select(`
        *,
        profiles:user_id (id, username, display_name, avatar_url)
      `)
      .or(`title.ilike.%${query}%,description.ilike.%${query}%`)
      .order('created_at', { ascending: false })
      .limit(48);

    if (error) {
      console.error('Search error:', error);
      setVideos([]);
    } else {
      setVideos((data ?? []) as unknown as VideoWithDetails[]);
    }
    setLoading(false);
  }, [query]);

  useEffect(() => {
    fetchResults();
  }, [fetchResults]);

  return (
    <div className="px-4 py-4 sm:px-6">
      <h1 className="mb-4 text-lg font-medium text-neutral-300">
        {loading ? (
          'Searching...'
        ) : (
          <>Results for "<span className="text-white">{query}</span>" — {videos.length} videos</>
        )}
      </h1>

      {loading ? (
        <div className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="aspect-video rounded-xl bg-neutral-800" />
              <div className="mt-2 flex gap-3">
                <div className="h-9 w-9 rounded-full bg-neutral-800" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 w-3/4 rounded bg-neutral-800" />
                  <div className="h-3 w-1/2 rounded bg-neutral-800" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : videos.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Search size={48} className="text-neutral-600" />
          <p className="mt-4 text-lg font-medium text-neutral-300">No results found</p>
          <p className="mt-1 text-sm text-neutral-500">Try a different search term.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {videos.map((video) => (
            <VideoCard key={video.id} video={video} onNavigate={onNavigate} />
          ))}
        </div>
      )}
    </div>
  );
}
