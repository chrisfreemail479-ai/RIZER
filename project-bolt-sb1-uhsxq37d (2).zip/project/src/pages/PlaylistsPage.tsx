import { useState, useEffect, useCallback } from 'react';
import { Plus, Lock, Globe, Trash2, ListVideo, X, Search, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Playlist, PlaylistItem, VideoWithDetails } from '@/types';
import { VideoCard } from '@/components/VideoCard';

interface PlaylistsPageProps {
  onNavigate: (path: string) => void;
  onOpenAuth: () => void;
}

export function PlaylistsPage({ onNavigate, onOpenAuth }: PlaylistsPageProps) {
  const { user } = useAuth();
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPublic, setNewPublic] = useState(false);
  const [selectedPlaylist, setSelectedPlaylist] = useState<Playlist | null>(null);
  const [items, setItems] = useState<PlaylistItem[]>([]);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<VideoWithDetails[]>([]);
  const [searching, setSearching] = useState(false);

  const fetchPlaylists = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('playlists')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    const pls = (data ?? []) as Playlist[];

    if (pls.length > 0) {
      const ids = pls.map((p) => p.id);
      const { data: itemsData } = await supabase.from('playlist_items').select('playlist_id').in('playlist_id', ids);
      const counts: Record<string, number> = {};
      (itemsData ?? []).forEach((i) => { counts[i.playlist_id] = (counts[i.playlist_id] ?? 0) + 1; });
      pls.forEach((p) => { p.item_count = counts[p.id] ?? 0; });
    }
    setPlaylists(pls);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchPlaylists();
  }, [fetchPlaylists]);

  const createPlaylist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newName.trim()) return;
    const { data } = await supabase
      .from('playlists')
      .insert({ user_id: user.id, name: newName.trim(), description: newDesc.trim() || null, is_public: newPublic })
      .select('*')
      .single();
    if (data) {
      setPlaylists((prev) => [{ ...data as Playlist, item_count: 0 }, ...prev]);
      setNewName(''); setNewDesc(''); setNewPublic(false); setShowCreate(false);
    }
  };

  const deletePlaylist = async (id: string) => {
    await supabase.from('playlists').delete().eq('id', id).eq('user_id', user!.id);
    setPlaylists((prev) => prev.filter((p) => p.id !== id));
    if (selectedPlaylist?.id === id) setSelectedPlaylist(null);
  };

  const openPlaylist = async (pl: Playlist) => {
    setSelectedPlaylist(pl);
    const { data } = await supabase
      .from('playlist_items')
      .select(`
        *,
        videos:video_id (
          id, user_id, title, description, video_type, video_url, youtube_id,
          thumbnail_url, views, is_short, music_title, clip_duration, created_at,
          profiles:user_id (id, username, display_name, avatar_url)
        )
      `)
      .eq('playlist_id', pl.id)
      .order('position', { ascending: true });
    setItems((data ?? []) as unknown as PlaylistItem[]);
  };

  const removeItem = async (itemId: string) => {
    await supabase.from('playlist_items').delete().eq('id', itemId);
    setItems((prev) => prev.filter((i) => i.id !== itemId));
  };

  const searchVideos = useCallback(async () => {
    if (!searchQuery.trim()) { setSearchResults([]); return; }
    setSearching(true);
    const { data } = await supabase
      .from('videos')
      .select(`*, profiles:user_id (id, username, display_name, avatar_url)`)
      .or(`title.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%`)
      .order('created_at', { ascending: false })
      .limit(12);
    setSearchResults((data ?? []) as unknown as VideoWithDetails[]);
    setSearching(false);
  }, [searchQuery]);

  useEffect(() => {
    const timer = setTimeout(() => { if (searchQuery.trim()) searchVideos(); else setSearchResults([]); }, 400);
    return () => clearTimeout(timer);
  }, [searchQuery, searchVideos]);

  const addVideoToPlaylist = async (videoId: string) => {
    if (!selectedPlaylist) return;
    const { data: existing } = await supabase.from('playlist_items').select('id').eq('playlist_id', selectedPlaylist.id).eq('video_id', videoId).maybeSingle();
    if (existing) return;
    const { count } = await supabase.from('playlist_items').select('id', { count: 'exact', head: true }).eq('playlist_id', selectedPlaylist.id);
    await supabase.from('playlist_items').insert({ playlist_id: selectedPlaylist.id, video_id: videoId, position: count ?? 0 });
    const { data: fullItem } = await supabase
      .from('playlist_items')
      .select(`*, videos:video_id (id, user_id, title, description, video_type, video_url, youtube_id, thumbnail_url, views, is_short, music_title, clip_duration, created_at, profiles:user_id (id, username, display_name, avatar_url))`)
      .eq('playlist_id', selectedPlaylist.id)
      .eq('video_id', videoId)
      .maybeSingle();
    if (fullItem) setItems((prev) => [...prev, fullItem as unknown as PlaylistItem]);
  };

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <ListVideo size={48} className="text-neutral-600" />
        <p className="mt-4 text-lg font-medium text-neutral-300">Sign in to use playlists</p>
        <button onClick={onOpenAuth} className="mt-4 rounded-lg bg-gradient-to-r from-red-500 to-orange-500 px-5 py-2 text-sm font-semibold text-white transition hover:from-red-600 hover:to-orange-600">Sign In</button>
      </div>
    );
  }

  if (selectedPlaylist) {
    return (
      <div className="px-4 py-6 sm:px-6">
        <div className="mb-6 flex items-center gap-3">
          <button onClick={() => setSelectedPlaylist(null)} className="text-neutral-400 transition hover:text-white"><X size={20} /></button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-white">{selectedPlaylist.name}</h1>
            <p className="text-sm text-neutral-400">
              {selectedPlaylist.is_public ? 'Public' : 'Private'} • {items.length} videos
            </p>
          </div>
          <button onClick={() => setShowSearch(!showSearch)} className="flex items-center gap-1.5 rounded-full bg-neutral-800 px-3 py-2 text-sm font-medium text-white transition hover:bg-neutral-700">
            <Search size={16} /> <span className="hidden sm:inline">Add Video</span>
          </button>
          <button onClick={() => deletePlaylist(selectedPlaylist.id)} className="text-neutral-500 transition hover:text-red-400"><Trash2 size={18} /></button>
        </div>

        {showSearch && (
          <div className="mb-6 rounded-lg border border-neutral-800 bg-neutral-900 p-4">
            <div className="relative mb-3">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for videos to add..."
                className="w-full rounded-lg border border-neutral-700 bg-neutral-950 py-2 pl-9 pr-3 text-sm text-white outline-none focus:border-neutral-500"
              />
              {searching && <Loader2 size={16} className="absolute right-3 top-1/2 -translate-y-1/2 animate-spin text-neutral-500" />}
            </div>
            {searchResults.length > 0 && (
              <div className="space-y-2">
                {searchResults.map((video) => (
                  <div key={video.id} className="flex items-center gap-3 rounded-lg p-2 transition hover:bg-neutral-800">
                    <div className="h-12 w-20 flex-shrink-0 overflow-hidden rounded bg-neutral-800">
                      {video.thumbnail_url && <img src={video.thumbnail_url} alt="thumb" className="h-full w-full object-cover" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-white">{video.title}</p>
                      <p className="truncate text-xs text-neutral-500">{video.profiles?.display_name}</p>
                    </div>
                    <button onClick={() => addVideoToPlaylist(video.id)} className="rounded-lg bg-red-500 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-red-600">Add</button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        {items.length === 0 ? (
          <p className="py-12 text-center text-sm text-neutral-500">No videos in this playlist yet.</p>
        ) : (
          <div className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {items.map((item) => (
              <div key={item.id} className="relative group">
                <VideoCard video={item.videos as any} onNavigate={onNavigate} />
                <button
                  onClick={() => removeItem(item.id)}
                  className="absolute right-2 top-2 rounded-full bg-black/70 p-1.5 text-white opacity-0 transition hover:bg-black group-hover:opacity-100"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-6 sm:px-6">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-bold text-white">My Playlists</h1>
        <button onClick={() => setShowCreate(!showCreate)} className="flex items-center gap-1.5 rounded-full bg-neutral-800 px-4 py-2 text-sm font-medium text-white transition hover:bg-neutral-700">
          <Plus size={16} /> New Playlist
        </button>
      </div>

      {showCreate && (
        <form onSubmit={createPlaylist} className="mb-6 space-y-3 rounded-lg border border-neutral-800 bg-neutral-900 p-4">
          <input type="text" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Playlist name" maxLength={100} className="w-full rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-2 text-sm text-white outline-none focus:border-neutral-500" required />
          <textarea value={newDesc} onChange={(e) => setNewDesc(e.target.value)} placeholder="Description (optional)" rows={2} className="w-full resize-none rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-2 text-sm text-white outline-none focus:border-neutral-500" />
          <label className="flex items-center gap-2 text-sm text-neutral-300">
            <input type="checkbox" checked={newPublic} onChange={(e) => setNewPublic(e.target.checked)} className="rounded" />
            {newPublic ? <Globe size={14} className="text-green-400" /> : <Lock size={14} className="text-neutral-400" />}
            Make public
          </label>
          <div className="flex gap-2">
            <button type="button" onClick={() => setShowCreate(false)} className="rounded-lg px-4 py-2 text-sm text-neutral-400 hover:bg-neutral-800">Cancel</button>
            <button type="submit" className="rounded-lg bg-gradient-to-r from-red-500 to-orange-500 px-4 py-2 text-sm font-semibold text-white transition hover:from-red-600 hover:to-orange-600">Create</button>
          </div>
        </form>
      )}

      {loading ? (
        <div className="flex justify-center py-12"><div className="h-8 w-8 animate-spin rounded-full border-2 border-neutral-700 border-t-red-500" /></div>
      ) : playlists.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <ListVideo size={48} className="text-neutral-600" />
          <p className="mt-4 text-sm text-neutral-500">No playlists yet. Create one to organize your favorite videos.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {playlists.map((pl) => (
            <div key={pl.id} onClick={() => openPlaylist(pl)} className="flex cursor-pointer items-center gap-4 rounded-lg border border-neutral-800 bg-neutral-900 p-4 transition hover:bg-neutral-800">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-red-500/20 to-orange-500/20">
                {pl.is_public ? <Globe size={20} className="text-green-400" /> : <Lock size={20} className="text-neutral-400" />}
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-medium text-white">{pl.name}</h3>
                <p className="text-xs text-neutral-500">{pl.item_count ?? 0} videos • {pl.is_public ? 'Public' : 'Private'}</p>
              </div>
              <button onClick={(e) => { e.stopPropagation(); deletePlaylist(pl.id); }} className="text-neutral-600 transition hover:text-red-400"><Trash2 size={16} /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
