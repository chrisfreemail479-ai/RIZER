import { useState, useEffect, useCallback } from 'react';
import { ThumbsUp, ThumbsDown, Share2, Trash2, Send, CornerDownRight } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { VideoWithDetails, Comment } from '@/types';
import { formatViews, timeAgo, getYouTubeEmbedUrl, formatCount } from '@/lib/utils';
import { VideoCard } from '@/components/VideoCard';
import { SubscribeButton } from '@/components/SubscribeButton';

interface WatchPageProps {
  videoId: string;
  onNavigate: (path: string) => void;
  onOpenAuth: () => void;
}

interface CommentWithMeta extends Comment {
  like_count: number;
  liked_by_me: boolean;
  replies: CommentWithMeta[];
}

export function WatchPage({ videoId, onNavigate, onOpenAuth }: WatchPageProps) {
  const { user, profile } = useAuth();
  const [video, setVideo] = useState<VideoWithDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [comments, setComments] = useState<CommentWithMeta[]>([]);
  const [newComment, setNewComment] = useState('');
  const [likeCount, setLikeCount] = useState(0);
  const [liked, setLiked] = useState(false);
  const [relatedVideos, setRelatedVideos] = useState<VideoWithDetails[]>([]);
  const [commentCount, setCommentCount] = useState(0);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  const fetchVideo = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('videos')
      .select(`
        *,
        profiles:user_id (id, username, display_name, avatar_url)
      `)
      .eq('id', videoId)
      .maybeSingle();

    if (error || !data) {
      setVideo(null);
      setLoading(false);
      return;
    }

    const v = data as unknown as VideoWithDetails;

    const [{ count: likes }, { count: cmts }] = await Promise.all([
      supabase.from('likes').select('*', { count: 'exact', head: true }).eq('video_id', videoId),
      supabase.from('comments').select('*', { count: 'exact', head: true }).eq('video_id', videoId),
    ]);

    let myLiked = false;
    if (user) {
      const { data: myLike } = await supabase
        .from('likes')
        .select('id')
        .eq('video_id', videoId)
        .eq('user_id', user.id)
        .maybeSingle();
      myLiked = !!myLike;
    }

    v.like_count = likes ?? 0;
    v.comment_count = cmts ?? 0;
    v.liked_by_me = myLiked;
    setVideo(v);
    setLikeCount(likes ?? 0);
    setLiked(myLiked);
    setCommentCount(cmts ?? 0);
    setLoading(false);

    supabase.rpc('increment_views', { video_uuid: videoId }).then(() => {});

    if (user) {
      supabase
        .from('watch_history')
        .upsert({ user_id: user.id, video_id: videoId, watched_at: new Date().toISOString() }, { onConflict: 'user_id,video_id' })
        .then(() => {});
    }

    const { data: related } = await supabase
      .from('videos')
      .select(`
        *,
        profiles:user_id (id, username, display_name, avatar_url)
      `)
      .neq('id', videoId)
      .order('created_at', { ascending: false })
      .limit(10);
    setRelatedVideos((related ?? []) as unknown as VideoWithDetails[]);
  }, [videoId, user]);

  const fetchComments = useCallback(async () => {
    const { data } = await supabase
      .from('comments')
      .select(`
        *,
        profiles:user_id (id, username, display_name, avatar_url)
      `)
      .eq('video_id', videoId)
      .order('created_at', { ascending: false });

    const allComments = (data ?? []) as unknown as Comment[];
    const commentIds = allComments.map((c) => c.id);

    let likeMap: Record<string, number> = {};
    let myLikes: Record<string, boolean> = {};
    if (commentIds.length > 0) {
      const { data: clData } = await supabase.from('comment_likes').select('comment_id, user_id').in('comment_id', commentIds);
      (clData ?? []).forEach((cl) => {
        likeMap[cl.comment_id] = (likeMap[cl.comment_id] ?? 0) + 1;
        if (user && cl.user_id === user.id) myLikes[cl.comment_id] = true;
      });
    }

    const withMeta: CommentWithMeta[] = allComments.map((c) => ({
      ...c,
      like_count: likeMap[c.id] ?? 0,
      liked_by_me: !!myLikes[c.id],
      replies: [],
    }));

    const topLevel = withMeta.filter((c) => !c.parent_id);
    const replyMap: Record<string, CommentWithMeta[]> = {};
    withMeta.filter((c) => c.parent_id).forEach((r) => {
      if (!replyMap[r.parent_id!]) replyMap[r.parent_id!] = [];
      replyMap[r.parent_id!].push(r);
    });
    topLevel.forEach((c) => {
      c.replies = replyMap[c.id] ?? [];
    });

    setComments(topLevel);
  }, [videoId, user]);

  useEffect(() => {
    fetchVideo();
    fetchComments();
  }, [fetchVideo, fetchComments]);

  const handleLike = async () => {
    if (!user) { onOpenAuth(); return; }
    if (liked) {
      await supabase.from('likes').delete().eq('video_id', videoId).eq('user_id', user.id);
      setLiked(false); setLikeCount((c) => c - 1);
    } else {
      await supabase.from('likes').insert({ video_id: videoId, user_id: user.id });
      setLiked(true); setLikeCount((c) => c + 1);
    }
  };

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newComment.trim()) return;
    const { data } = await supabase
      .from('comments')
      .insert({ video_id: videoId, user_id: user.id, content: newComment.trim() })
      .select(`*, profiles:user_id (id, username, display_name, avatar_url)`)
      .single();
    if (data) {
      const c = data as unknown as Comment;
      setComments((prev) => [{ ...c, like_count: 0, liked_by_me: false, replies: [] }, ...prev]);
      setNewComment('');
      setCommentCount((c) => c + 1);
    }
  };

  const handleReply = async (parentId: string) => {
    if (!user || !replyText.trim()) return;
    const { data } = await supabase
      .from('comments')
      .insert({ video_id: videoId, user_id: user.id, content: replyText.trim(), parent_id: parentId })
      .select(`*, profiles:user_id (id, username, display_name, avatar_url)`)
      .single();
    if (data) {
      const r = data as unknown as Comment;
      setComments((prev) =>
        prev.map((c) =>
          c.id === parentId
            ? { ...c, replies: [...c.replies, { ...r, like_count: 0, liked_by_me: false, replies: [] }] }
            : c
        )
      );
      setReplyText('');
      setReplyingTo(null);
      setCommentCount((c) => c + 1);
    }
  };

  const handleCommentLike = async (commentId: string, isLiked: boolean) => {
    if (!user) { onOpenAuth(); return; }
    if (isLiked) {
      await supabase.from('comment_likes').delete().eq('comment_id', commentId).eq('user_id', user.id);
    } else {
      await supabase.from('comment_likes').insert({ comment_id: commentId, user_id: user.id });
    }
    setComments((prev) =>
      prev.map((c) => {
        if (c.id === commentId) {
          return { ...c, liked_by_me: !isLiked, like_count: c.like_count + (isLiked ? -1 : 1) };
        }
        return {
          ...c,
          replies: c.replies.map((r) =>
            r.id === commentId
              ? { ...r, liked_by_me: !isLiked, like_count: r.like_count + (isLiked ? -1 : 1) }
              : r
          ),
        };
      })
    );
  };

  const handleDeleteComment = async (commentId: string) => {
    await supabase.from('comments').delete().eq('id', commentId).eq('user_id', user!.id);
    setComments((prev) => prev.filter((c) => c.id !== commentId && c.parent_id !== commentId));
    setCommentCount((c) => c - 1);
  };

  const handleDeleteVideo = async () => {
    if (!video || video.user_id !== user?.id) return;
    if (!confirm('Delete this video? This cannot be undone.')) return;
    if (video.video_type === 'file' && video.video_url) {
      await supabase.storage.from('videos').remove([video.video_url]);
    }
    if (video.thumbnail_url && video.video_type === 'file' && video.thumbnail_url) {
      await supabase.storage.from('thumbnails').remove([video.thumbnail_url]);
    }
    await supabase.from('videos').delete().eq('id', videoId);
    onNavigate('/');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-neutral-700 border-t-red-500" />
      </div>
    );
  }

  if (!video) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <p className="text-lg font-medium text-neutral-300">Video not found</p>
        <button onClick={() => onNavigate('/')} className="mt-4 text-red-400 hover:text-red-300">Go home</button>
      </div>
    );
  }

  const renderAvatar = (avatarUrl?: string | null, name?: string, size = 'h-9 w-9') => (
    <div className={`${size} flex-shrink-0 overflow-hidden rounded-full bg-gradient-to-br from-red-500 to-orange-500`}>
      {avatarUrl ? (
        <img src={avatarUrl} alt="avatar" className="h-full w-full object-cover" />
      ) : (
        <div className={`flex h-full w-full items-center justify-center text-sm font-bold text-white`}>
          {(name?.[0] ?? 'U').toUpperCase()}
        </div>
      )}
    </div>
  );

  return (
    <div className="px-4 py-4 sm:px-6">
      <div className="mx-auto max-w-6xl">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            {/* Player */}
            <div className="aspect-video overflow-hidden rounded-xl bg-black">
              {video.video_type === 'youtube' && video.youtube_id ? (
                <iframe src={getYouTubeEmbedUrl(video.youtube_id)} className="h-full w-full" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen title={video.title} />
              ) : video.video_url ? (
                <video src={video.video_url} className="h-full w-full" controls poster={video.thumbnail_url ?? undefined} />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-neutral-500">Video unavailable</div>
              )}
            </div>

            <h1 className="mt-3 text-lg font-bold text-white sm:text-xl">{video.title}</h1>

            {/* Channel + actions */}
            <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <button onClick={() => onNavigate(`/channel/${video.user_id}`)} className="h-10 w-10 overflow-hidden rounded-full bg-gradient-to-br from-red-500 to-orange-500">
                  {video.profiles?.avatar_url ? (
                    <img src={video.profiles.avatar_url} alt="avatar" className="h-full w-full object-cover" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center font-bold text-white">{(video.profiles?.display_name?.[0] ?? 'U').toUpperCase()}</div>
                  )}
                </button>
                <div>
                  <button onClick={() => onNavigate(`/channel/${video.user_id}`)} className="text-sm font-medium text-white hover:text-neutral-200">{video.profiles?.display_name}</button>
                  <p className="text-xs text-neutral-400">{formatViews(video.views)} • {timeAgo(video.created_at)}</p>
                </div>
                {video.user_id !== user?.id && (
                  <div className="ml-2">
                    <SubscribeButton channelId={video.user_id} onOpenAuth={onOpenAuth} />
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button onClick={handleLike} className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition ${liked ? 'bg-red-500/20 text-red-400' : 'bg-neutral-800 text-neutral-200 hover:bg-neutral-700'}`}>
                  <ThumbsUp size={16} className={liked ? 'fill-red-400' : ''} /> {formatCount(likeCount)}
                </button>
                <button className="flex items-center gap-2 rounded-full bg-neutral-800 px-4 py-2 text-sm font-medium text-neutral-200 transition hover:bg-neutral-700"><ThumbsDown size={16} /></button>
                <button className="flex items-center gap-2 rounded-full bg-neutral-800 px-4 py-2 text-sm font-medium text-neutral-200 transition hover:bg-neutral-700"><Share2 size={16} /><span className="hidden sm:inline">Share</span></button>
                {video.user_id === user?.id && (
                  <button onClick={handleDeleteVideo} className="flex items-center gap-2 rounded-full bg-neutral-800 px-4 py-2 text-sm font-medium text-red-400 transition hover:bg-neutral-700"><Trash2 size={16} /></button>
                )}
              </div>
            </div>

            {/* Description */}
            {video.description && (
              <div className="mt-4 rounded-lg bg-neutral-900 p-3"><p className="text-sm text-neutral-300">{video.description}</p></div>
            )}

            {/* Comments */}
            <div className="mt-6">
              <h2 className="mb-4 text-base font-bold text-white">{commentCount} Comments</h2>

              {user ? (
                <form onSubmit={handleComment} className="mb-6 flex gap-3">
                  {renderAvatar(profile?.avatar_url, profile?.display_name)}
                  <div className="flex-1">
                    <input type="text" value={newComment} onChange={(e) => setNewComment(e.target.value)} placeholder="Add a comment..." className="w-full border-b border-neutral-700 bg-transparent pb-1 text-sm text-white outline-none transition focus:border-neutral-500" />
                    {newComment && (
                      <div className="mt-2 flex justify-end gap-2">
                        <button type="button" onClick={() => setNewComment('')} className="rounded-full px-3 py-1.5 text-sm text-neutral-400 hover:bg-neutral-800">Cancel</button>
                        <button type="submit" className="flex items-center gap-1.5 rounded-full bg-red-500 px-3 py-1.5 text-sm font-medium text-white transition hover:bg-red-600"><Send size={14} /> Comment</button>
                      </div>
                    )}
                  </div>
                </form>
              ) : (
                <div className="mb-6 rounded-lg border border-neutral-800 bg-neutral-900 p-4 text-center">
                  <p className="text-sm text-neutral-400">You need to <button onClick={onOpenAuth} className="font-medium text-red-400 hover:text-red-300">sign in</button> to leave a comment.</p>
                </div>
              )}

              <div className="space-y-4">
                {comments.map((comment) => (
                  <div key={comment.id}>
                    <div className="flex gap-3">
                      <button onClick={() => onNavigate(`/channel/${comment.user_id}`)}>{renderAvatar(comment.profiles?.avatar_url, comment.profiles?.display_name)}</button>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-white">{comment.profiles?.display_name}</span>
                          <span className="text-xs text-neutral-500">{timeAgo(comment.created_at)}</span>
                        </div>
                        <p className="mt-0.5 text-sm text-neutral-300">{comment.content}</p>
                        <div className="mt-1.5 flex items-center gap-3">
                          <button onClick={() => handleCommentLike(comment.id, comment.liked_by_me)} className={`flex items-center gap-1 text-xs transition ${comment.liked_by_me ? 'text-red-400' : 'text-neutral-400 hover:text-neutral-200'}`}>
                            <ThumbsUp size={12} className={comment.liked_by_me ? 'fill-red-400' : ''} /> {comment.like_count > 0 && formatCount(comment.like_count)}
                          </button>
                          {user && (
                            <button onClick={() => setReplyingTo(replyingTo === comment.id ? null : comment.id)} className="text-xs text-neutral-400 transition hover:text-neutral-200">Reply</button>
                          )}
                          {comment.user_id === user?.id && (
                            <button onClick={() => handleDeleteComment(comment.id)} className="text-neutral-500 transition hover:text-red-400"><Trash2 size={12} /></button>
                          )}
                        </div>

                        {/* Reply input */}
                        {replyingTo === comment.id && user && (
                          <div className="mt-2 flex gap-2">
                            {renderAvatar(profile?.avatar_url, profile?.display_name, 'h-7 w-7')}
                            <div className="flex-1">
                              <input type="text" value={replyText} onChange={(e) => setReplyText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') handleReply(comment.id); }} placeholder="Add a reply..." className="w-full border-b border-neutral-700 bg-transparent pb-1 text-sm text-white outline-none focus:border-neutral-500" />
                              <div className="mt-1 flex justify-end gap-2">
                                <button onClick={() => { setReplyingTo(null); setReplyText(''); }} className="rounded-full px-2 py-1 text-xs text-neutral-400 hover:bg-neutral-800">Cancel</button>
                                <button onClick={() => handleReply(comment.id)} className="rounded-full bg-red-500 px-2 py-1 text-xs font-medium text-white hover:bg-red-600">Reply</button>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Replies */}
                        {comment.replies.length > 0 && (
                          <div className="mt-3 space-y-3 border-l border-neutral-800 pl-4">
                            {comment.replies.map((reply) => (
                              <div key={reply.id} className="flex gap-2">
                                <button onClick={() => onNavigate(`/channel/${reply.user_id}`)}>{renderAvatar(reply.profiles?.avatar_url, reply.profiles?.display_name, 'h-7 w-7')}</button>
                                <div className="flex-1">
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs font-medium text-white">{reply.profiles?.display_name}</span>
                                    <span className="text-xs text-neutral-500">{timeAgo(reply.created_at)}</span>
                                  </div>
                                  <p className="mt-0.5 text-sm text-neutral-300">{reply.content}</p>
                                  <div className="mt-1 flex items-center gap-3">
                                    <button onClick={() => handleCommentLike(reply.id, reply.liked_by_me)} className={`flex items-center gap-1 text-xs transition ${reply.liked_by_me ? 'text-red-400' : 'text-neutral-400 hover:text-neutral-200'}`}>
                                      <ThumbsUp size={12} className={reply.liked_by_me ? 'fill-red-400' : ''} /> {reply.like_count > 0 && formatCount(reply.like_count)}
                                    </button>
                                    {reply.user_id === user?.id && (
                                      <button onClick={() => handleDeleteComment(reply.id)} className="text-neutral-500 transition hover:text-red-400"><Trash2 size={12} /></button>
                                    )}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Related videos */}
          <div className="lg:col-span-1">
            <h2 className="mb-3 text-base font-bold text-white">Up Next</h2>
            <div className="space-y-3">
              {relatedVideos.map((rv) => (
                <div key={rv.id} className="flex gap-2">
                  <div className="relative w-40 flex-shrink-0">
                    <VideoCard video={rv} onNavigate={onNavigate} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
