import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { VideoWithDetails } from '@/types';
import { VideoCard } from '@/components/VideoCard';

interface HomePageProps {
  onNavigate: (path: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const [videos, setVideos] = useState<VideoWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchVideos = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('videos')
      .select(`
        *,
        profiles:user_id (id, username, display_name, avatar_url)
      `)
      .order('created_at', { ascending: false })
      .limit(48);

    if (error) {
      console.error('Error fetching videos:', error);
      setVideos([]);
    } else {
      const vids = (data ?? []) as unknown as VideoWithDetails[];
      if (vids.length > 0) {
        const videoIds = vids.map((v) => v.id);
        const [{ data: likesData }, { data: commentsData }] = await Promise.all([
          supabase.from('likes').select('video_id').in('video_id', videoIds),
          supabase.from('comments').select('video_id').in('video_id', videoIds),
        ]);
        const likeCounts: Record<string, number> = {};
        const commentCounts: Record<string, number> = {};
        (likesData ?? []).forEach((l) => {
          likeCounts[l.video_id] = (likeCounts[l.video_id] ?? 0) + 1;
        });
        (commentsData ?? []).forEach((c) => {
          commentCounts[c.video_id] = (commentCounts[c.video_id] ?? 0) + 1;
        });
        vids.forEach((v) => {
          v.like_count = likeCounts[v.id] ?? 0;
          v.comment_count = commentCounts[v.id] ?? 0;
        });
      }
      setVideos(vids);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchVideos();
  }, [fetchVideos]);

  return (
    <div className="px-4 py-4 sm:px-6">
      {loading ? (
        <div className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="aspect-video rounded-xl bg-neutral-800" />
              <div className="mt-2 flex gap-3">
                <div className="h-9 w-9 rounded-full bg-neutral-800" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 w-3/4 rounded bg-neutral-800" />
                  <div className="h-3 w-1/2 rounded bg-neutral-800" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : videos.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <p className="text-lg font-medium text-neutral-300">No videos yet</p>
          <p className="mt-1 text-sm text-neutral-500">Be the first to upload a video to RIZER!</p>
          <button
            onClick={() => onNavigate('/upload')}
            className="mt-4 rounded-lg bg-gradient-to-r from-red-500 to-orange-500 px-5 py-2 text-sm font-semibold text-white transition hover:from-red-600 hover:to-orange-600"
          >
            Upload Video
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {videos.map((video) => (
            <VideoCard key={video.id} video={video} onNavigate={onNavigate} />
          ))}
        </div>
      )}
    </div>
  );
}
