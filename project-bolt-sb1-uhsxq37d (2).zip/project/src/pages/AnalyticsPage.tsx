import { useState, useEffect, useCallback } from 'react';
import { Eye, ThumbsUp, MessageCircle, Video, TrendingUp, Loader2, BarChart3 } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { formatViews, formatCount, timeAgo } from '@/lib/utils';

interface AnalyticsPageProps {
  onNavigate: (path: string) => void;
}

interface VideoStats {
  id: string;
  title: string;
  thumbnail_url: string | null;
  youtube_id: string | null;
  views: number;
  likes: number;
  comments: number;
  created_at: string;
}

export function AnalyticsPage({ onNavigate }: AnalyticsPageProps) {
  const { user } = useAuth();
  const [videos, setVideos] = useState<VideoStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [live, setLive] = useState(true);

  const fetchStats = useCallback(async () => {
    if (!user) return;
    const { data: vids, error } = await supabase
      .from('videos')
      .select('id, title, thumbnail_url, youtube_id, views, created_at')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error || !vids) {
      setLoading(false);
      return;
    }

    const videoIds = vids.map((v) => v.id);
    let likeMap: Record<string, number> = {};
    let commentMap: Record<string, number> = {};

    if (videoIds.length > 0) {
      const [{ data: likes }, { data: comments }] = await Promise.all([
        supabase.from('likes').select('video_id').in('video_id', videoIds),
        supabase.from('comments').select('video_id').in('video_id', videoIds),
      ]);
      (likes ?? []).forEach((l) => {
        likeMap[l.video_id] = (likeMap[l.video_id] ?? 0) + 1;
      });
      (comments ?? []).forEach((c) => {
        commentMap[c.video_id] = (commentMap[c.video_id] ?? 0) + 1;
      });
    }

    const stats: VideoStats[] = vids.map((v) => ({
      id: v.id,
      title: v.title,
      thumbnail_url: v.thumbnail_url,
      youtube_id: v.youtube_id,
      views: v.views,
      likes: likeMap[v.id] ?? 0,
      comments: commentMap[v.id] ?? 0,
      created_at: v.created_at,
    }));

    setVideos(stats);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  // Live polling every 10 seconds
  useEffect(() => {
    if (!live || !user) return;
    const interval = setInterval(() => {
      fetchStats();
    }, 10000);
    return () => clearInterval(interval);
  }, [live, user, fetchStats]);

  // Realtime subscription for new likes and comments
  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel('analytics-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'likes' }, () => fetchStats())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'comments' }, () => fetchStats())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'videos', filter: `user_id=eq.${user.id}` }, () => fetchStats())
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, fetchStats]);

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <BarChart3 size={48} className="text-neutral-600" />
        <p className="mt-4 text-lg font-medium text-neutral-300">Sign in to view analytics</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 size={32} className="animate-spin text-neutral-600" />
      </div>
    );
  }

  const totalViews = videos.reduce((s, v) => s + v.views, 0);
  const totalLikes = videos.reduce((s, v) => s + v.likes, 0);
  const totalComments = videos.reduce((s, v) => s + v.comments, 0);
  const totalVideos = videos.length;

  // Simple bar chart data — views per video (top 10)
  const chartData = videos.slice(0, 10);
  const maxViews = Math.max(...chartData.map((v) => v.views), 1);

  return (
    <div className="px-4 py-6 sm:px-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Channel Analytics</h1>
          <p className="mt-1 text-sm text-neutral-400">Real-time performance of your videos</p>
        </div>
        <button
          onClick={() => setLive(!live)}
          className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition ${
            live
              ? 'bg-green-500/20 text-green-400'
              : 'bg-neutral-800 text-neutral-400'
          }`}
        >
          <span className={`h-2 w-2 rounded-full ${live ? 'animate-pulse bg-green-400' : 'bg-neutral-500'}`} />
          {live ? 'Live' : 'Paused'}
        </button>
      </div>

      {/* Summary cards */}
      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={Video} label="Total Videos" value={formatCount(totalVideos)} color="from-blue-500/20 to-blue-600/10" iconColor="text-blue-400" />
        <StatCard icon={Eye} label="Total Views" value={formatCount(totalViews)} color="from-red-500/20 to-red-600/10" iconColor="text-red-400" />
        <StatCard icon={ThumbsUp} label="Total Likes" value={formatCount(totalLikes)} color="from-orange-500/20 to-orange-600/10" iconColor="text-orange-400" />
        <StatCard icon={MessageCircle} label="Total Comments" value={formatCount(totalComments)} color="from-green-500/20 to-green-600/10" iconColor="text-green-400" />
      </div>

      {/* Bar chart */}
      {chartData.length > 0 && (
        <div className="mb-6 rounded-xl border border-neutral-800 bg-neutral-900 p-4 sm:p-6">
          <h2 className="mb-4 flex items-center gap-2 text-sm font-medium text-neutral-300">
            <TrendingUp size={16} /> Views by Video
          </h2>
          <div className="space-y-3">
            {chartData.map((v, i) => (
              <div key={v.id} className="group">
                <div className="mb-1 flex items-center justify-between gap-2">
                  <p className="truncate text-xs text-neutral-400">
                    <span className="text-neutral-500">#{i + 1}</span> {v.title}
                  </p>
                  <span className="flex-shrink-0 text-xs font-medium text-neutral-300">{formatViews(v.views)}</span>
                </div>
                <div className="h-6 overflow-hidden rounded-md bg-neutral-800">
                  <div
                    className="h-full rounded-md bg-gradient-to-r from-red-500 to-orange-500 transition-all duration-500"
                    style={{ width: `${(v.views / maxViews) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Per-video table */}
      {videos.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Video size={48} className="text-neutral-600" />
          <p className="mt-4 text-lg font-medium text-neutral-300">No videos to analyze yet</p>
          <button
            onClick={() => onNavigate('/upload')}
            className="mt-4 rounded-lg bg-gradient-to-r from-red-500 to-orange-500 px-5 py-2 text-sm font-semibold text-white transition hover:from-red-600 hover:to-orange-600"
          >
            Upload Your First Video
          </button>
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl border border-neutral-800">
          <table className="w-full">
            <thead>
              <tr className="border-b border-neutral-800 bg-neutral-900">
                <th className="px-4 py-3 text-left text-xs font-medium text-neutral-400">Video</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-neutral-400">Views</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-neutral-400">Likes</th>
                <th className="hidden px-4 py-3 text-right text-xs font-medium text-neutral-400 sm:table-cell">Comments</th>
                <th className="hidden px-4 py-3 text-right text-xs font-medium text-neutral-400 sm:table-cell">Published</th>
              </tr>
            </thead>
            <tbody>
              {videos.map((v) => (
                <tr
                  key={v.id}
                  onClick={() => onNavigate(`/watch/${v.id}`)}
                  className="cursor-pointer border-b border-neutral-800/50 bg-neutral-900/50 transition hover:bg-neutral-800/50"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-16 flex-shrink-0 overflow-hidden rounded bg-neutral-800">
                        {v.thumbnail_url || v.youtube_id ? (
                          <img
                            src={v.thumbnail_url || `https://img.youtube.com/vi/${v.youtube_id}/hqdefault.jpg`}
                            alt={v.title}
                            className="h-full w-full object-cover"
                          />
                        ) : null}
                      </div>
                      <p className="line-clamp-1 text-sm text-neutral-200">{v.title}</p>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-right text-sm font-medium text-white">{formatCount(v.views)}</td>
                  <td className="px-4 py-3 text-right text-sm text-neutral-300">{formatCount(v.likes)}</td>
                  <td className="hidden px-4 py-3 text-right text-sm text-neutral-300 sm:table-cell">{formatCount(v.comments)}</td>
                  <td className="hidden px-4 py-3 text-right text-xs text-neutral-400 sm:table-cell">{timeAgo(v.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color, iconColor }: {
  icon: LucideIcon;
  label: string;
  value: string;
  color: string;
  iconColor: string;
}) {
  return (
    <div className={`rounded-xl border border-neutral-800 bg-gradient-to-br ${color} p-4`}>
      <div className="mb-2 flex items-center justify-between">
        <Icon size={20} className={iconColor} />
      </div>
      <p className="text-2xl font-bold text-white">{value}</p>
      <p className="mt-0.5 text-xs text-neutral-400">{label}</p>
    </div>
  );
}
