import { useState, useEffect, useCallback } from 'react';
import { ThumbsUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { VideoWithDetails } from '@/types';
import { VideoCard } from '@/components/VideoCard';

interface LikedPageProps {
  onNavigate: (path: string) => void;
  onOpenAuth: () => void;
}

export function LikedPage({ onNavigate, onOpenAuth }: LikedPageProps) {
  const { user } = useAuth();
  const [videos, setVideos] = useState<VideoWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLiked = useCallback(async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('likes')
      .select(`
        created_at,
        videos:video_id (
          *,
          profiles:user_id (id, username, display_name, avatar_url)
        )
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(100);

    if (error || !data) {
      setVideos([]);
      setLoading(false);
      return;
    }

    const vids = data
      .map((row) => (row as unknown as { videos: VideoWithDetails }).videos)
      .filter(Boolean) as VideoWithDetails[];
    setVideos(vids);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchLiked();
  }, [fetchLiked]);

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <ThumbsUp size={48} className="text-neutral-600" />
        <p className="mt-4 text-lg font-medium text-neutral-300">Sign in to see your liked videos</p>
        <p className="mt-1 text-sm text-neutral-500">Videos you like will be collected here.</p>
        <button
          onClick={onOpenAuth}
          className="mt-4 rounded-lg bg-gradient-to-r from-red-500 to-orange-500 px-5 py-2 text-sm font-semibold text-white transition hover:from-red-600 hover:to-orange-600"
        >
          Sign In
        </button>
      </div>
    );
  }

  return (
    <div className="px-4 py-6 sm:px-6">
      <div className="mb-6 flex items-center gap-3">
        <ThumbsUp size={24} className="text-neutral-300" />
        <div>
          <h1 className="text-2xl font-bold text-white">Liked Videos</h1>
          <p className="mt-0.5 text-sm text-neutral-400">{videos.length} {videos.length === 1 ? 'video' : 'videos'} you've liked</p>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="aspect-video rounded-xl bg-neutral-800" />
              <div className="mt-2 flex gap-3">
                <div className="h-9 w-9 rounded-full bg-neutral-800" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 w-3/4 rounded bg-neutral-800" />
                  <div className="h-3 w-1/2 rounded bg-neutral-800" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : videos.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <ThumbsUp size={48} className="text-neutral-600" />
          <p className="mt-4 text-lg font-medium text-neutral-300">No liked videos yet</p>
          <p className="mt-1 text-sm text-neutral-500">Tap the like button on any video to save it here.</p>
          <button
            onClick={() => onNavigate('/')}
            className="mt-4 rounded-lg bg-neutral-800 px-5 py-2 text-sm font-semibold text-white transition hover:bg-neutral-700"
          >
            Browse Videos
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {videos.map((video) => (
            <VideoCard key={video.id} video={video} onNavigate={onNavigate} />
          ))}
        </div>
      )}
    </div>
  );
}
